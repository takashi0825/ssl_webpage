## C++ source codes of the optimization benchmark problem for the series-parallel switching of photovoltaic modules programming ##
These codes are edited by the investigating R&D commitee on new development of computational intelligence techniques and their applications to industrial systems, the institute of electrical engineers of Japan.

These codes are based on the series-parallel switching of photovoltaic modules optimization problem in the references [1] and [2].
Specific formulation used in this implementation is given in "P6_formulation.pdf".
[1] T. Hayashi: "The serial-parallel switching of photovoltaic modules and mixed integer programming", Proc. of the 2014 Annual Meeting on the Institute of Electrical Engineers of Japan (Mar. 2014) [in Japanese]
[2] T. Hayashi: "Effectiveness evaluation of optimization of series-parallel switching of photovoltaic modules by time-series data", Proc. of the 2017 Annual Meeting on the Institute of Electrical Engineers of Japan (Mar. 2017) [in Japanese]

-- Files --
# P6.cpp: P6 (the serial-parallel switching of photovoltaic modules programming problem) class main file.
# P6.h: P6 class header file.
# P6_evaluation.cpp: sample file to test P6 class.
# P6_solution_x.txt: the solution evaluated in P6_sample.cpp.
# P6_solution_y.txt: the solution evaluated in P6_sample.cpp.
# P6_tolerance.conf: tolerance for constraint violations.
# P6_TS_time.txt: the time of the time-series data
# P6_TS_T.txt: the temperature time-series data
# P6_TS_S_RAD.txt: the solar radiation time-series data
# P6_zzz.conf: constants read in the private method "P6::initialization" of P6.cpp.

-- Implementing the sample code --
# Visual C++
	cl P6.cpp P6_evaluation.cpp /FeP6.exe /EHsc
	P6.exe
# gcc
	g++ P6.cpp P6_evaluation.cpp -o P6.out
	./P6.out

-- Public methods --
# void P6::evaluation(double *x, double *y, double *f, double *g, double *h)
  This function sets objective function values f(x, y) to f, inequality condition function values g(x, y) to g, and equality condition function values h(x, y) to h.
# void P6::checkFeasibility(double *x, double *y)
  This function returns feasibility of decision variables.
# void P6::setParameters(const int t)
  This sample code reads all time-series data in the constructor.
  This function set C, I_SC, and V_OC based on the data at the step t.
  The user has to call this method to specify the problem before evaluating the objective function and the constraints.
  The time-series data are from 2012/7/9 0:00 (t = 0) to 2012/7/16 23:59 (t = 11519).

-- Public properties --
# int P6.N_x: number of continuous decision variables
# int P6.N_y: number of discrete decision variables
# int P6.P: number of objective funcitons
# int P6.M: number of inequality conditions
# int P6.Q: number of equality conditions
# double P6.eps: tolerance for constraint violations
# string * P6.time_string: time strings of the time-series data
