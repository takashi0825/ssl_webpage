/*
 * P6 class sample
 * Written by Takashi Okamoto (takashi@faculty.chiba-u.jp)
 * Last update on Apr. 21st, 2017
 */
#include "P6.h"
#include <iostream>
#include <fstream>
using namespace std;

int main()
{
	//Preparation
	double *x, *y, *f, *g, *h; //Variable declaration
	P6 OF; //Create P6 class instance
	x = new double [OF.N_x]; //Memory allocation for x
	y = new double [OF.N_y]; //Memory allocation for y
	f = new double [OF.P]; //Memory allocation for f
	g = new double [OF.M]; //Memory allocation for g
	h = new double [OF.Q]; //Memory allocation for h

	//Set (choose) parameters
	int t = 679;
	OF.setParameters(t);
	cout << OF.time_string[t] << endl;

	//Set the best known solution
	ifstream ifs("P6_solution_x.txt");
	for (int n = 0; n < OF.N_x; n++) {
		ifs >> x[n];
	}
	ifs.close();
	ifs.open("P6_solution_y.txt");
	for (int n = 0; n < OF.N_y; n++) {
		ifs >> y[n];
	}

	//Evaluation
	OF.evaluation(x, y, f, g, h);

	//Output
	cout.precision(10);
	cout << "x = ";
	for (int n = 0; n < OF.N_x; n++) {
		cout << x[n] << " ";
	}
	cout << endl;
	cout << "y = ";
	for (int n = 0; n < OF.N_y; n++) {
		cout << y[n] << " ";
	}
	cout << endl;
	for (int p = 0; p < OF.P; p++) {
		cout << "f" << p + 1 << " = " << f[p] << endl;
	}
	double V = 0.0;
	for (int m = 0; m < OF.M; m++) {
		cout << "g" << m + 1 << " = " << g[m] << endl;
		if (g[m] > 0) {
			V += g[m];
		}
	}
	for (int q = 0; q < OF.Q; q++) {
		cout << "h" << q + 1 << " = " << h[q] << endl;
		V += fabs(h[q]);
	}

	//Check feasibility
	cout << "Sum of violation = " << V << endl;
	cout << "Tolerance = " << OF.eps << endl;
	if (OF.checkFeasibility(x, y)) {
		cout << "Input solution is feasible.";
	} else {
		cout << "Input solution is infeasible.";
	}

	return 0;
}
