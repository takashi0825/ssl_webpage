/*
 * An optimization benchmark problem for the series-parallel switching of photovoltaic modules programming
 * (main file)
 * Written by Takashi Okamoto (takashi@faculty.chiba-u.jp)
 * Last update on Apr. 21st, 2017
 */
#include "P6.h"

/* Constructor */
P6::P6()
{
	//Set constants
	initialization();

	/* Set common variables */
	N_x = N + K;
	N_y = N - 1;
	P = 1;
	M = N * 2 + K * 2 + 2 + K * 2 + K * 2;
	Q = N + 1 + K - 1;

	//Memory allocation
	x_i = new double [N];
	x_v = new double [K];
	kn = new int [N];
	I = new double [K];
	I_SC_sum = new double [K];
	C = new double [N];
	I_SC = new double [N];
	V_OC = new double [N];
}

/* Destructor */
P6::~P6()
{
	//Memory release
	delete [] x_i;
	delete [] x_v;
	delete [] kn;
	delete [] I;
	delete [] I_SC_sum;
	delete [] C;
	delete [] I_SC;
	delete [] V_OC;
	delete [] R_S;
	delete [] R_SH;
	delete [] T;
	delete [] time_string;
	for (int i = 0; i < N; i++) {
		delete [] S_RAD[i];
	}
	delete [] S_RAD;
}

/* Evaluation function */
void P6::evaluation(double *x, double *y, double *f, double *g, double *h)
{
	//Set x_i and x_v
	for (int n = 0; n < N; n++) {
		x_i[n] = x[n];
	}
	for (int k = 0; k < K; k++) {
		x_v[k] = x[k + N];
	}

	//Set k
	setK(y);

	//Set I
	setI();

	//Compute objective function - Eq. (3a)
	f[0] = 0.0;
	for (int n = 0; n < N; n++) {
		f[0] += x_i[n] * x_v[kn[n]];
	}

	/* Compute constraint conditions */
	int id_g = 0, id_h = 0;

	//Eq. (3b)
	for (int n = 0; n < N; n++) {
		g[id_g] = -x_i[n];
		id_g++;
	}
	for (int n = 0; n < N; n++) {
		g[id_g] = x_i[n] - I_MM;
		id_g++;
	}

	//Eq. (3c)
	for (int k = 0; k < K; k++) {
		g[id_g] = -x_v[k];
		id_g++;
	}
	for (int k = 0; k < K; k++) {
		g[id_g] = x_v[k] - V_MM;
		id_g++;
	}

	//Eq. (3d)
	for (int n = 0; n < N; n++) {
		h[id_h] = computeF(n, kn[n]);
		id_h++;
	}

	//Eq. (3e)
	double sum = 0.0;
	for (int n = 0; n < N - 1; n++) {
		sum += y[n];
	}
	h[id_h] = sum + 1.0 - (double)K;
	id_h++;

	//Eq. (3f)
	sum = 0.0;
	for (int k = 0; k < K; k++) {
		sum += x_v[k];
	}
	g[id_g] = V_Sm - sum;
	id_g++;
	g[id_g] = sum - V_SM;
	id_g++;

	//Eq. (3g)
	for (int k = 1; k < K; k++) {
		h[id_h] = I[k] - I[0];
		id_h++;
	}

	//Eq. (3h)
	for (int k = 0; k < K; k++) {
		g[id_g] = -I[k];
		id_g++;
	}
	for (int k = 0; k < K; k++) {
		g[id_g] = I[k] - I_MM;
		id_g++;
	}

	//Eq. (3i)
	for (int k = 0; k < K; k++) {
		I_SC_sum[k] = 0.0;
	}
	for (int n = 0; n < N; n++) {
		I_SC_sum[kn[n]] += I_SC[n];
	}
	for (int k = 0; k < K; k++) {
		g[id_g] = -I_SC_sum[k];
		id_g++;
	}
	for (int k = 0; k < K; k++) {
		g[id_g] = I_SC_sum[k] - I_MM;
		id_g++;
	}
}

/* Evaluation function */
void P6::gradient(double *x, double *y, double *fx, double **gx, double **hx)
{
	//Initialization
	for (int n = 0; n < N_x; n++) {
		fx[n] = 0.0;
	}
	for (int m = 0; m < M; m++) {
		for (int n = 0; n < N_x; n++) {
			gx[m][n] = 0.0;
		}
	}
	for (int q = 0; q < Q; q++) {
		for (int n = 0; n < N_x; n++) {
			hx[q][n] = 0.0;
		}
	}

	//Set x_i and x_v
	for (int n = 0; n < N; n++) {
		x_i[n] = x[n];
	}
	for (int k = 0; k < K; k++) {
		x_v[k] = x[k + N];
	}

	//Set k
	setK(y);

	//Set I
	setI();

	//Compute objective function - Eq. (3a)
	for (int n = 0; n < N; n++) {
		fx[n] = x_v[kn[n]];
		fx[kn[n] + N] += x_i[n];
	}

	/* Compute constraint conditions */
	int id_g = 0, id_h = 0;

	//Eq. (3b)
	for (int n = 0; n < N; n++) {
		gx[id_g][n] = -1.0;
		id_g++;
	}
	for (int n = 0; n < N; n++) {
		gx[id_g][n] = 1.0;
		id_g++;
	}

	//Eq. (3c)
	for (int k = 0; k < K; k++) {
		gx[id_g][N + k] = -1.0;
		id_g++;
	}
	for (int k = 0; k < K; k++) {
		gx[id_g][N + k] = 1.0;
		id_g++;
	}

	//Eq. (3d)
	for (int n = 0; n < N; n++) {
		int k = kn[n];
		bool check = true;
		if (x_i[n] > I_SC[n] - eps && fabs(x_v[k]) < eps) {
//			check = false;
		}
		if (x_v[k] > V_OC[n] - eps && fabs(x_i[k]) < eps) {
//			check = false;
		}
		if (check) {
			hx[id_h][n] = -(exp(C[n] * (-V_OC[n] + x_i[n] * R_S[n] + x_v[k])) * C[n] * R_S[n] * (I_SC[n] - (V_OC[n] - I_SC[n] * R_S[n]) / R_SH[n])) / (1.0 - exp(C[n] * (I_SC[n] * R_S[n] - V_OC[n]))) - R_S[n] / R_SH[n] - 1.0;
			hx[id_h][k + N] = -(exp(C[n] * (-V_OC[n] + x_i[n] * R_S[n] + x_v[k])) * C[n] * (I_SC[n] - (V_OC[n] - I_SC[n] * R_S[n]) / R_SH[n])) / (1.0 - exp(C[n] * (I_SC[n] * R_S[n] - V_OC[n]))) - 1.0 / R_SH[n];
		}
		id_h++;
	}

	//Eq. (3e)
	id_h++;

	//Eq. (3f)
	for (int k = 0; k < K; k++) {
		gx[id_g][k + N] = -1.0;
		gx[id_g + 1][k + N] = 1.0;
	}
	id_g++;
	id_g++;

	//Eq. (3g)
	for (int k = 1; k < K; k++) {
		for (int n = 0; n < N; n++) {
			if (kn[n] == 0) {
				hx[id_h][n] = -1.0;
			}
			if (kn[n] == k) {
				hx[id_h][n] = 1.0;
			}
		}
		id_h++;
	}

	//Eq. (3h)
	for (int k = 0; k < K; k++) {
		for (int n = 0; n < N; n++) {
			if (kn[n] == k) {
				gx[id_g][n] = -1.0;
			}
		}
		id_g++;
	}
	for (int k = 0; k < K; k++) {
		for (int n = 0; n < N; n++) {
			if (kn[n] == k) {
				gx[id_g][n] = 1.0;
			}
		}
		id_g++;
	}

	//Eq. (3i)
	for (int k = 0; k < K; k++) {
		id_g++;
	}
	for (int k = 0; k < K; k++) {
		id_g++;
	}
}

/* Check feasibility */
bool P6::checkFeasibility(double *x, double *y)
{
	/* Check feasibility of y */
	bool feasibility = true;
	for (int n = 0; n < N_y; n++) {
		if (y[n] < 0 || y[n] > 2) {
			feasibility = false;
		}
	}

	/* Compute f, g, and h */
	double *f, *g, *h;
	f = new double[P];
	g = new double[M];
	h = new double[Q];
	evaluation(x, y, f, g, h);

	/* Check inequality conditions */
	for (int m = 0; m < M; m++) {
		if (g[m] > eps) {
			feasibility = false;
		}
	}

	/* Check equality conditions */
	for (int q = 0; q < Q; q++) {
		if (fabs(h[q]) > eps){
			feasibility = false;
		}
	}

	/* Memory release */
	delete [] f;
	delete [] g;
	delete [] h;

	return feasibility;
}

/* Set parameters at the step t */
void P6::setParameters(const int t)
{
	//Set C
	for (int n = 0; n < N; n++) {
		C[n] = 118.6958 / T[t];
	}

	//Set I_SC
	for (int n = 0; n < N; n++) {
		I_SC[n] = I_SCU * S_RAD[t][n];
	}

	//Set V_OC
	for (int n = 0; n < N; n++) {
		V_OC[n] = 46.6 - 0.121 * (T[t] - 298.0);
	}
}

/* Private methoTS */
void P6::initialization()
{
	//Read constants
	std::ifstream ifs;
	ifs.open("P6_constants.conf");
	std::string tmp;
	ifs >> tmp >> N >> tmp >> K >> tmp >> I_MM >> tmp >> V_MM >> tmp >> V_Sm >> tmp >> V_SM >> tmp >> I_SCU >> tmp >> N_data;
	ifs.close();

	//Read tolerance for constraint violations
	ifs.open("P6_tolerance.conf");
	ifs >> eps;
	ifs.close();

	//Read array constants
	readArray(&R_S, N, "P6_R_S.conf");
	readArray(&R_SH, N, "P6_R_SH.conf");

	//Read time series data
	readArray(&time_string, N_data, "P6_TS_time.txt");
	readArray(&T, N_data, "P6_TS_T.txt");
	readArray(&S_RAD, N_data, N, "P6_TS_S_RAD.txt");
}

void P6::readArray(double **A, const int N, const std::string &filename)
{
	std::ifstream ifs(filename.c_str());
	*A = new double [N];
	for (int i = 0; i < N; i++) {
		ifs >> (*A)[i];
	}
	ifs.close();
}

void P6::readArray(double ***A, const int N, const int M, const std::string &filename)
{
	std::ifstream ifs(filename.c_str());
	(*A) = new double *[N];
	for (int i = 0; i < N; i++) {
		(*A)[i] = new double [M];
		for (int j = 0; j < M; j++) {
			ifs >> (*A)[i][j];
		}
	}
	ifs.close();
}

void P6::readArray(std::string **A, const int N, const std::string &filename)
{
	std::ifstream ifs(filename.c_str());
	*A = new std::string [N];
	for (int i = 0; i < N; i++) {
		std::getline(ifs, (*A)[i]);
	}
	ifs.close();
}

void P6::setK(double *y)
{
	kn[0] = 0;
	int sum = 0;
	for (int n = 1; n < N - 1; n++) {
		kn[n] = sum;
		sum += (int)y[n];
	}
	kn[N - 1] = sum;
}

void P6::setI()
{
	for (int k = 0; k < K; k++) {
		I[k] = 0.0;
	}
	for (int n = 0; n < N; n++) {
		I[kn[n]] += x_i[n];
	}
}

double P6::computeF(const int n, const int k)
{
	if (x_i[n] > I_SC[n] - eps && fabs(x_v[k]) < eps) {
		return 0.0;
	}
	if (x_v[k] > V_OC[n] - eps && fabs(x_i[n]) < eps) {
		return 0.0;
	}
	return (I_SC[n] - (V_OC[n] - R_S[n] * I_SC[n]) / R_SH[n]) * (1.0 - exp(C[n] * (x_v[k] + R_S[n] * x_i[n] - V_OC[n]))) / (1.0 - exp(C[n] * (R_S[n] * I_SC[n] - V_OC[n]))) - (x_v[k] + R_S[n] * x_i[n] - V_OC[n]) / R_SH[n] - x_i[n];
}
