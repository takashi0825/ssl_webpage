/*
 * An optimization benchmark problem for the series-parallel switching of photovoltaic modules programming
 * (header file)
 * Written by Takashi Okamoto (takashi@faculty.chiba-u.jp)
 * Last update on Apr. 21st, 2017
 *
 * Variables
 *  x : continuous decision variables
 *  y : discrete decision variables
 *  N_x : number of continuous decision variables
 *  N_y : number of discrete decision variables
 *  P : number of objective funcitons
 *  M : number of inequality conditions
 *  Q : number of equality conditions
 *  eps : tolerance for constraint violations
 *
 * Funcitons
 *  "evaluation" sets objective function values to f,
 *  inequality condition function values to g, and
 *  equality condition function values to h.
 *  "checkFeasibility" returns feasibility of decision variables
 */
#include <cmath>
#include <string>
#include <fstream>

class P6 {
public:
	//Constructor
	P6();

	//Public methods
	void evaluation(double *, double *, double *, double *, double *);
	void gradient(double *, double *, double *, double **, double **);
	bool checkFeasibility(double *, double *);
	void setParameters(const int);

	//Constants
	int N_x, N_y, P, M, Q, N_data; //Common variables
	double eps; //Common variables
	int N, K, *kn;
	double I_MM, V_MM, V_Sm, V_SM, *I_SC, *V_OC, *R_S, *C, *R_SH, *I, *I_SC_sum, I_SCU, **S_RAD, *T;
	std::string *time_string;

	//Destructor
	~P6();

private:
	//Private methods
	void initialization();
	void readArray(double **, const int, const std::string &);
	void readArray(double ***, const int, const int, const std::string &);
	void readArray(std::string **, const int, const std::string &);
	void setK(double *);
	void setI();
	double computeF(const int, const int);

	//Private members
	double *x_i, *x_v;
};
