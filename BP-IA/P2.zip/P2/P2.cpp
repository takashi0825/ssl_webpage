/*
 * An optimization benchmark problem for water supply pump scheduling
 * (main file)
 * Written by Takashi Okamoto (takashi@faculty.chiba-u.jp)
 * Last update on June 3rd, 2014
 */
#include "P2.h"

/* Constructor */
P2::P2()
{
	//Set constants
	initialization();

	/* Set common variables */
	N_x = 0;
	N_y = K;
	P = 2;
	M = 3 * K + 1;
	Q = 0;
}

/* Destructor */
P2::~P2()
{
	//Release memory
	delete [] c;
	delete [] q;
}

/* Evaluation function */
void P2::evaluation(double *x, double *y, double *f, double *g, double *h)
{
	//Compute water level (Eq. (3.6h))
	double l[24];
	l[0] = l_0 + (computeQprime((double)y[0]) * (double)y[0] - q[0]) / S;
	for (int k = 1; k < K; k++) {
		l[k] = l[k - 1] + (computeQprime((double)y[k]) * (double)y[k] - q[k]) / S;
	}

	//Compute objective function values
	f[0] = abs(y_0 - y[0]);
	for (int k = 1; k < K; k++) {
		f[0] += abs(y[k - 1] - y[k]);
	}
	f[1] = 0.0;
	for (int k = 0; k < K; k++) {
		f[1] += c[k] * computeP((double)y[k]);
	}

	//Compute inequality conditions
	int id = 0;

	//l^min - l_k(y) < 0 (left side of Eq. (3.6b))
	for (int k = 0; k < K; k++) {
		g[id] = l_min - l[k];
		id++;
	}

	//l_k(y) - l^max (right side of Eq. (3.6b))
	for (int k = 0; k < K; k++) {
		g[id] = l[k] - l_max;
		id++;
	}

	//Eq. (3.6c)
	g[id] = (double)(abs(y_0 - y[0]) - R);
	id++;
	for (int k = 1; k < K; k++) {
		g[id] = (double)(abs(y[k - 1] - y[k]) - R);
		id++;
	}

	//Eq. (3.6d)
	g[id] = fabs(l_0 - l[K - 1]) - L;
	id++;
}

/* Check feasibility */
bool P2::checkFeasibility(double *x, double *y)
{
	/* Check feasibility of y */
	bool feasibility = true;
	for (int n = 0; n < N_y; n++) {
		if (y[n] < 0 || y[n] > N) {
			feasibility = false;
		}
	}

	/* Compute f, g, and h */
	double *f, *g, *h;
	f = new double[P];
	g = new double[M];
	h = new double[Q];
	evaluation(x, y, f, g, h);

	/* Check inequality conditions */
	for (int m = 0; m < M; m++) {
		if (g[m] > eps) {
			feasibility = false;
		}
	}

	/* Check equality conditions */
	for (int q = 0; q < Q; q++) {
		if (fabs(h[q]) > eps){
			feasibility = false;
		}
	}

	/* Memory release */
	delete [] f;
	delete [] g;
	delete [] h;

	return feasibility;
}

/* Private methods */
void P2::initialization()
{
	//Read constants
	std::ifstream ifs;
	ifs.open("P2_constants.conf");
	std::string tmp;
	ifs >> tmp >> K >> tmp >> l_min >> tmp >> l_max >> tmp >> R >> tmp >> N >> tmp >> y_0 >> tmp >> L >> tmp >> l_0 >> tmp >> S >> tmp >> param_a >> tmp >> param_b >> tmp >> param_c >> tmp >> param_d >> tmp >> param_e >> tmp >> param_f >> tmp >> r >> tmp >> H;
	ifs.close();

	//Read tolerance for constraint violations
	ifs.open("P2_tolerance.conf");
	ifs >> eps;
	ifs.close();

	//Read array constants
	readArray(&c, K, "P2_c.conf");
	readArray(&q, K, "P2_q.conf");
}

void P2::readArray(double **A, const int N, const std::string &filename)
{
	std::ifstream ifs(filename.c_str());
	*A = new double [N];
	for (int i = 0; i < N; i++) {
		ifs >> (*A)[i];
	}
	ifs.close();
}

void P2::readArray(int **A, const int N, const std::string &filename)
{
	std::ifstream ifs(filename.c_str());
	*A = new int [N];
	for (int i = 0; i < N; i++) {
		ifs >> (*A)[i];
	}
	ifs.close();
}

double P2::computeQprime(const double y_k)
{
	return (param_b + sqrt(param_b * param_b - 4.0 * (y_k * y_k * r - param_a) * (H - param_c))) / (2.0 * (y_k * y_k * r - param_a));
}

double P2::computeP(const double y_k)
{
	double Qprime = computeQprime(y_k);
	double Q_k = Qprime * (double)y_k;
	double h = r * Q_k * Q_k + H;
	double eta = param_d * Qprime * Qprime + param_e * Qprime + param_f;
	return 9.8 / 3600.0 * 24.0 / (double)K * h * Q_k / eta;
}
