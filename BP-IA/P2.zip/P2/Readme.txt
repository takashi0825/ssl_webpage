## C++ source codes of the optimization benchmark problem for the water supply pump scheduling ##
These codes are based on the water supply pump scheduling problem in [1].
[1] Investigating R&D committee on new development of computational intelligence techniques and their applications to industrial systems Eds.: "Optimization Benchmark Problems for Industrial Applications", IEEJ Tech. Rep. No. 1287 (July 2013) [in Japanese]

These codes are edited by the investigating R&D commitee on new development of computational intelligence techniques and their applications to industrial systems, the institute of electrical engineers of Japan.

-- Files --
# P2.cpp: P2 (the water supply scheduling problem) class main file.
# P2.h: P2 class header file.
# P2_evaluation.cpp: sample file to test P2 class.
# P2_solution_y.txt: the solution evaluated in P2_evaluation.cpp.
# P2_tolerance.conf: tolerance for constraint violations.
# P2_zzz.conf: constants read in the private method "P2::initialization" of P2.cpp.

-- Implementing the sample code --
# Visual C++
	cl P2.cpp P2_evaluation.cpp /FeP2.exe /EHsc
	P2.exe
# gcc
	g++ P2.cpp P2_evaluation.cpp -o P2.out
	./P2.out

-- Public methods --
# void P2::evaluation(double *x, double *y, double *f, double *g, double *h)
  This function sets objective function values f(x, y) to f, inequality condition function values g(x, y) to g, and equality condition function values h(x, y) to h.
# void P2::checkFeasibility(double *x, double *y)
  This function returns feasibility of decision variables.

-- Public properties --
# int P2.N_x : number of continuous decision variables
# int P2.N_y : number of discrete decision variables
# int P2.P : number of objective funcitons
# int P2.M : number of inequality conditions
# int P2.Q : number of equality conditions
# double P2.eps : tolerance for constraint violations
