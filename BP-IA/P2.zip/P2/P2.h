/*
 * An optimization benchmark problem for water supply pump scheduling
 * (header file)
 * Written by Takashi Okamoto (takashi@faculty.chiba-u.jp)
 * Last update on Dec. 28th, 2013
 * 
 * Variables
 *  x : continuous decision variables
 *  y : discrete decision variables
 *  N_x : number of continuous decision variables
 *  N_y : number of discrete decision variables
 *  P : number of objective funcitons
 *  M : number of inequality conditions
 *  Q : number of equality conditions
 *
 * Funcitons
 *  "evaluation" sets objective function values to f, 
 *  inequality condition function values to g, and 
 *  equality condition function values to h.
 *  "checkFeasibility" returns feasibility of decision variables
 */
#include <cmath>
#include <string>
#include <fstream>

class P2 {
public:
	//Constructor
	P2();

	//Public methods
	void evaluation(double *, double *, double *, double *, double *);
	bool checkFeasibility(double *, double *);

	//Constants
	int N_x, N_y, P, M, Q; //common variables
	double eps; //common variables
	int K, R, N, y_0;
	double l_min, l_max, L, l_0, S, r, H;
	double param_a, param_b, param_c, param_d, param_e, param_f; //a, b, c, d, e, f in Table 1
	double *c, *q;

	//Destructor
	~P2();

private:
	//Private methods
	void initialization();
	void readArray(double **, const int, const std::string &);
	void readArray(int **, const int, const std::string &);
	double computeQprime(const double); //Eq. (3.6i)
	double computeP(const double); // Eq. (3.6k)
};
