% An optimization benchmark problem for the energy plant operational planning problem
% Written by Takashi Okamoto (takashi@faculty.chiba-u.jp)
% Last update on Oct. 5th, 2014

% Set format
format longG;

% Get x and set y
x = importdata('P1_solution_x.txt');
y = (x > 1.0E-10);

% Initialization
P1 = P1_initialization();

% Evaluation
[f, g, h] = P1_evaluation(P1, x, y)

% Check feasiblity
P1_checkFeasibility(P1, x, y)
