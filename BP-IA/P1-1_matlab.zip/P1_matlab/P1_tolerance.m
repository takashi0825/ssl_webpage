% An optimization benchmark problem for the energy plant operational planning problem
% Written by Takashi Okamoto (takashi@faculty.chiba-u.jp)
% Last update on Oct. 5th, 2014

P1.eps = 1.0E-10;
