% An optimization benchmark problem for the energy plant operational planning problem
% Written by Takashi Okamoto (takashi@faculty.chiba-u.jp)
% Last update on Oct. 5th, 2014

function [f, g, h] = P1_evaluation(P1, x, y)
	% Substitution of x and y
	idx = 1;
	x_t = zeros(0, 0);
	y_t = zeros(0, 0);
	for j = 1:P1.N_t
		x_t = vertcat(x_t, x(idx:idx + P1.I - 1)');
		y_t = vertcat(y_t, y(idx:idx + P1.I - 1)');
		idx = idx + P1.I;
	end
	x_s = zeros(0, 0);
	y_s = zeros(0, 0);
	for j = 1:P1.N_s
		x_s = vertcat(x_s, x(idx:idx + P1.I - 1)');
		y_s = vertcat(y_s, y(idx:idx + P1.I - 1)');
		idx = idx + P1.I;
	end
	x_g = x(idx:idx + P1.I - 1)';
	y_g = y(idx:idx + P1.I - 1)';
	idx = idx + P1.I;
	x_b = x(idx:idx + P1.I - 1)';
	y_b = y(idx:idx + P1.I - 1)';
	idx = idx + P1.I;

	% Compute Q_ts
	Q_ts = zeros(1, P1.I);
	Q_ts(1) = P1_computeQ(P1, 1, P1.Q_ts_init, x_t, x_s);
	for i = 2:P1.I
		Q_ts(i) = P1_computeQ(P1, i, Q_ts(i - 1), x_t, x_s);
	end

	% Compute E_r
	E_r = P1.a_t .* x_t + P1.E_L - P1.a_ge * x_g + P1.E_rm;

	% Compute f_sj
	f_sj = x_s ./ (-repmat(P1.a_s, 1, P1.I) .* x_s .* x_s + repmat(P1.b_s, 1, P1.I) .* x_s + repmat(P1.c_s, 1, P1.I));

	% Compute objective function - Eq. (6a)
	f(1) = sum(P1.C_Er .* E_r + P1.C_Fr .* (x_g + x_b));

	% Compute constraint conditions
	% Eq. (6b) and (6c)
	id_g = 1;
	g(id_g:id_g + P1.I - 1, 1) = (P1.Q_ts_min - Q_ts)';
	id_g = id_g + P1.I;
	g(id_g:id_g + P1.I - 2, 1) = (Q_ts(1, 1:P1.I - 1) - P1.Q_ts_max1)';
	g(id_g + P1.I - 1, 1) = Q_ts(1, P1.I) - P1.Q_ts_max2;
	id_g = id_g + P1.I;

	% Eq. (6d)
	id_h = 1;
	h(id_h:id_h + P1.I - 1, 1) = (P1.a_gs * x_g + P1.a_b * x_b - sum(f_sj) - P1.S_L - P1.S_rm)';
	id_h = id_h + P1.I;

	% Eq. (6e)
	for j = 1:P1.N_t
		g(id_g:id_g + P1.I - 1, 1) = (P1.Q_t_min(j) * y_t(j, :) - x_t(j, :))';
		id_g = id_g + P1.I;
	end
	for j = 1:P1.N_t
		g(id_g:id_g + P1.I - 1, 1) = (x_t(j, :) - P1.Q_t_max(j) * y_t(j, :))';
		id_g = id_g + P1.I;
	end

	% Eq. (6f)
	for j = 1:P1.N_s
		g(id_g:id_g + P1.I - 1, 1) = (P1.Q_s_min(j) * y_s(j, :) - x_s(j, :))';
		id_g = id_g + P1.I;
	end
	for j = 1:P1.N_s
		g(id_g:id_g + P1.I - 1, 1) = (x_s(j, :) - P1.Q_s_max(j) * y_s(j, :))';
		id_g = id_g + P1.I;
	end

	% Eq. (6g)
	g(id_g:id_g + P1.I - 1, 1) = (P1.E_g_min * y_g - P1.a_ge * x_g)';
	id_g = id_g + P1.I;
	g(id_g:id_g + P1.I - 1, 1) = (P1.a_ge * x_g - P1.E_g_max * y_g)';
	id_g = id_g + P1.I;

	% Eq. (6h)
	g(id_g:id_g + P1.I - 1, 1) = (P1.S_b_min * y_b - P1.a_b * x_b)';
	id_g = id_g + P1.I;
	g(id_g:id_g + P1.I - 1, 1) = (P1.a_b * x_b - P1.S_b_max * y_b)';
	id_g = id_g + P1.I;

	% Eq. (6i)
	for j = 1:P1.N_t
		for i = 1:P1.I - 1
			for tau = i + 2:i + P1.L_t(j)
				if (tau < P1.I + 1)
					h(id_h) = (y_t(j, i + 1) - y_t(j, i)) * (y_t(j, i + 1) - y_t(j, tau));
					id_h = id_h + 1;
				end
			end
		end
	end

	% Eq. (6j)
	for j = 1:P1.N_s
		for i = 1:P1.I - 1
			for tau = i + 2:i + P1.L_s(j)
				if (tau < P1.I + 1)
					h(id_h) = (y_s(j, i + 1) - y_s(j, i)) * (y_s(j, i + 1) - y_s(j, tau));
					id_h = id_h + 1;
				end
			end
		end
	end

	% Eq. (6k)
	for i = 1:P1.I - 1
		for tau = i + 2:i + P1.L_g
			if (tau < P1.I + 1)
				h(id_h) = (y_g(i + 1) - y_g(i)) * (y_g(i + 1) - y_g(tau));
				id_h = id_h + 1;
			end
		end
	end

	% Eq. (6l)
	for i = 1:P1.I - 1
		for tau = i + 2:i + P1.L_b
			if (tau < P1.I + 1)
				h(id_h) = (y_b(i + 1) - y_b(i)) * (y_b(i + 1) - y_b(tau));
				id_h = id_h + 1;
			end
		end
	end
end
