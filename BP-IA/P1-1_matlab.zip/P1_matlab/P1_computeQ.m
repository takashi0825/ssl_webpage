% An optimization benchmark problem for the energy plant operational planning problem
% Written by Takashi Okamoto (takashi@faculty.chiba-u.jp)
% Last update on Oct. 5th, 2014

function Q_ts_i = P1_computeQ(P1, i, Q_ts_i_minus_1, x_t, x_s)
	Q_ts_i = 0.0;
	Q_ts_i = Q_ts_i - sum(x_t(:, i));
	Q_ts_i = Q_ts_i - sum(x_s(:, i));
	Q_ts_i = Q_ts_i + Q_ts_i_minus_1 + P1.Q_L(i) + P1.Q_loss;
end
