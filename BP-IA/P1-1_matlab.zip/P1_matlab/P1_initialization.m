% An optimization benchmark problem for the energy plant operational planning problem
% Written by Takashi Okamoto (takashi@faculty.chiba-u.jp)
% Last update on Oct. 5th, 2014

function P1 = P1_initialization()
	% Read constants
	P1_constants;

	% Read tolerance for constraint violations
	P1_tolerance;

	% Set common variables
	P1.N_x = P1.I * (P1.N_t + P1.N_s + 2);
	P1.N_y = P1.I * (P1.N_t + P1.N_s + 2);
	P1.P = 1;
	P1.M = P1.I * (6 + 2 * P1.N_t + 2 * P1.N_s);
	P1.Q = (P1.I - P1.L_t(1)) + (P1.I - P1.L_s(1)) + (P1.I - P1.L_s(2)) + (P1.I - P1.L_g) + (P1.I - P1.L_b) + P1.I;
end
