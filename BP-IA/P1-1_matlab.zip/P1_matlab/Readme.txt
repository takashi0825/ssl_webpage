## MATLAB codes of the optimization benchmark problem for the energy plant operational planning problem ##
These codes are edited by the investigating R&D committee on system optimization and benchmark problems for industrial application, the institute of electrical engineers of Japan.

These codes are based on the energy plant operational planning problem in [1].
[1] T. Okamoto, N. Adachi, R. Suzuki, S. Koakutsu, and H. Hirata: "The energy plant operational planning problem and applications of optimization methods to the problem", Proc. of the 2014 Annual Meeting on the Institute of Electrical Engineers of Japan (Mar. 2014) [in Japanese]

-- Files --
# P1_initialization.m: read constants of P1 and set some constants
# P1_constants.m: constants read in P1_initialization.
# P1_tolerance.m: tolerance for constraint violations read in P1_initialization.
# P1_evaluation.m: P1 (the energy plant operational planning problem) evaluation functions
# P1_sample.m: sample file to test these codes
# P1_solution_x.txt: the solution evaluated in P1_sample.m.

-- Implementing the sample code --
Implement "P1_sample.m".

-- Functions --
# function [f, g, h] = P1_evaluation(P1, x, y)
  This function sets objective function values f(x, y) to f, inequality condition function values g(x, y) to g, and equality condition function values h(x, y) to h. P1 is structure made by P1_initialization.
# function P1_checkFeasibility(P1, x, y)
  This function returns feasibility of decision variables.

-- Public properties --
# P1.N_x : number of continuous decision variables
# P1.N_y : number of discrete decision variables
# P1.P : number of objective funcitons
# P1.M : number of inequality conditions
# P1.Q : number of equality conditions
# P1.eps : tolerance for constraint violations
