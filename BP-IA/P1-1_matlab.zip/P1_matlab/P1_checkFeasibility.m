% An optimization benchmark problem for the energy plant operational planning problem
% Written by Takashi Okamoto (takashi@faculty.chiba-u.jp)
% Last update on Oct. 5th, 2014

function feasibility = P1_checkFeasibility(P1, x, y)
	% Check feasibility of y
	feasibility = true;
	if (sum(y < 0) > 0 || sum(y > 2) > 0)
		feasibility = false;
	end

	% Compute f, g, and h
	[f, g, h] = P1_evaluation(P1, x, y);

	% Check inequality conditions
	if (sum(g > P1.eps) > 0)
		feasibility = false;
	end

	% Check equality conditions
	if (sum(abs(h) > P1.eps) > 0)
		feasibility = false;
	end
end
