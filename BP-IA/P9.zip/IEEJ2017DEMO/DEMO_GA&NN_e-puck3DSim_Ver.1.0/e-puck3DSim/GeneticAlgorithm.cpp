#include "GeneticAlgorithm.h"
#include "main.h"
#include "MathFunction.h"
#include "NeuralNetwork.h"

struct Agent AGENT[FAM_MAX];

int CNT_REPEAT;
int CNT_FAMILY;
int CNT_GENERATION;
int CNT_TRIAL;

int ELI_FIT[ELI_MAX];
int ELI[ELI_MAX];

int CNT_FALSE;
int CNT_SUCCESS;
double RESULT[TRIAL_MAX+1][GEN_MAX+1][5];
int SEED[TRIAL_MAX];
int SEED_TRIAL;


void GaInit(void){

	int g,i,j,k,l;
	double dis,dis_min=0.0;
	double dis_ave;

	SIM_STEP=1;
	CNT_REPEAT=0;
	CNT_FAMILY=0;
	CNT_GENERATION=0;

	AgentResetFamily();

	/*---------------------------------------------------------*/	
	/*****************�j���[�����l�b�g���[�N�����ݒ�***********/
	if (LOAD){
		for (g=0;g<FAM_MAX;g++){	
			for (i=0;i<N_MAX;i++){	
				for (k=0;k<DIM_N;k++){	
					AGENT[g].NEU[i][k]=0;
					AGENT[g].NEU_1[i][k]=0;
				}
			}
			for (i=0;i<SYN_MAX;i++){	
				for (k=0;k<DIM_S;k++){	
					AGENT[g].SYN[i][k]=0;
					AGENT[g].SYN_1[i][k]=0;
				}
			}
		}
		FILE *fp1;
  
		fopen_s(&fp1,"weight_binary.bin","rb"); /*�j���[�����̉׏d�ω��o�C�i��*/
  
		for (i=0;i<FAM_MAX;i++){
			for (k=0;k<N_MAX;k++){
				for (g=0;g<DIM_N;g++){
					fread(&AGENT[i].NEU[k][g],sizeof(double),1,fp1);
				}
			}
			for (k=0;k<SYN_MAX;k++){
				for (g=0;g<DIM_S;g++){
					fread(&AGENT[i].SYN[k][g],sizeof(double),1,fp1);
				}
			}
		}
		fclose(fp1);
	}
	else {
	jp2:;
		dis_ave=0;
		l=0;
		for (g=0;g<FAM_MAX;g++){	
			for (i=0;i<N_MAX;i++){	
				for (k=0;k<DIM_N;k++){	
					AGENT[g].NEU[i][k]=0;
					AGENT[g].NEU_1[i][k]=0;
				}
				NEU_SET(g,i);
			}
			jp1:;
			for (i=0;i<SYN_MAX;i++){	
				for (k=0;k<DIM_S;k++){	
					AGENT[g].SYN[i][k]=0;
					AGENT[g].SYN_1[i][k]=0;
				}
				SYN_SET(g,i);
			} 
		
			if (g>0){
				for (j=0;j<g;j++){
					dis=0;
					dis_min=STEP_MAX;
					for (i=0;i<SYN_MAX;i++){	
						dis=dis+((AGENT[g].SYN[i][W_0]-AGENT[j].SYN[i][W_0])/(S_WEIGHT_MA-S_WEIGHT_MI))
							*((AGENT[g].SYN[i][W_0]-AGENT[j].SYN[i][W_0])/(S_WEIGHT_MA-S_WEIGHT_MI));
					}
					dis=sqrt(dis);
					if (dis<SAMPLE_DIS_MIN_INI){
						l++;
						if (l>SETUP_ITE){
							printf("RESET\n");
							goto jp2;
						}
						goto jp1;
					}
					else{
						if (dis_min>dis)
							dis_min=dis;
						l=0;
					}
				}
				dis_ave=dis_ave+dis_min;
				printf("%d, ",g+1);
			}
			SetStructure(&AGENT[g]);
		}
		dis_ave=dis_ave/(FAM_MAX-1.0);
		printf("%f\n",dis_ave);
	}
	return;
}

void AgentReset(int fam_num){

	int i;

	AGENT[fam_num].goal_flag=false;
	AGENT[fam_num].output_sum=0.0;
	for (i=0;i<IN_NEU;i++){
		AGENT[fam_num].INPUT_NEU[i]=0.0;
	}
	for (i=0;i<OUT_NEU;i++){
		AGENT[fam_num].OUTPUT_NEU[i]=0.0;
	}
	for (i=0;i<SUBGOAL;i++){
		AGENT[fam_num].SUBGOAL_FLAG[i]=0;
	}

	return;
}

void AgentResetFamily(void){

	int i,j;
	for (i=0;i<FAM_MAX;i++){	
		AgentReset(i);
		AGENT[i].FITNESS=S_VALUE;
		AGENT[i].SUCCESS=0;
		for (j=0;j<REPEAT_MAX;j++){	
			AGENT[i].ENV_FIT[j]=S_VALUE;
		}
	}
}

void GaSubgoal(double x, double y){

  /**********************************************************************/
  if (x>=PASSAGE_WIDTH*0 && x<=PASSAGE_WIDTH*0.5
      && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
      //&& y>=PASSAGE_WIDTH*3 && y<=PASSAGE_WIDTH*4
      && AGENT[CNT_FAMILY].SUBGOAL_FLAG[0]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[0]=1;
  }
  else if (x>=PASSAGE_WIDTH*0 && x<=PASSAGE_WIDTH*0.5
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[0]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[1]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[1]=1;
  }
  else if (x>=PASSAGE_WIDTH*1 && x<=PASSAGE_WIDTH*2
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[1]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[2]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[2]=1;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[46]=0;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[48]=0;
  }
  else if (x>=PASSAGE_WIDTH*1 && x<=PASSAGE_WIDTH*2
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*0.5
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[2]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[3]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
      AGENT[CNT_FAMILY].SUBGOAL_FLAG[3]=1;
  }
  else if (x>=PASSAGE_WIDTH*2 && x<=PASSAGE_WIDTH*3
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[3]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[4]!=1){
      
      AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
      AGENT[CNT_FAMILY].SUBGOAL_FLAG[4]=1;
  }
  else if (x>=PASSAGE_WIDTH*2 && x<=PASSAGE_WIDTH*3 
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[4]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[5]!=1){

    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[5]=1;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[47]=0;
  }
  else if (x>=PASSAGE_WIDTH*4 && x<=PASSAGE_WIDTH*5 
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[5]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[6]!=1){
     
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[6]=1;
  }
  else if (x>=PASSAGE_WIDTH*4 && x<=PASSAGE_WIDTH*5 
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[6]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[7]!=1){
    
      AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
      AGENT[CNT_FAMILY].SUBGOAL_FLAG[7]=1;
  }
  else if (x>=PASSAGE_WIDTH*3 && x<=PASSAGE_WIDTH*4 
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[7]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[8]!=1){

    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[8]=1;      
  }
  else if (x>=PASSAGE_WIDTH*3 && x<=PASSAGE_WIDTH*4
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[8]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[9]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[9]=1;
  }
  else if (x>=PASSAGE_WIDTH*4 && x<=PASSAGE_WIDTH*5
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[9]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[10]!=1){
      
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[10]=1;
  }
  else if (x>=PASSAGE_WIDTH*4 && x<=PASSAGE_WIDTH*5
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[10]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[11]!=1){
      
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[11]=1;
  }
  else if (x>=PASSAGE_WIDTH*4 && x<=PASSAGE_WIDTH*5
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[11]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[12]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[12]=1;
  }
  else if (x>=PASSAGE_WIDTH*5 && x<=PASSAGE_WIDTH*6
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[12]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[13]!=1){
      
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[13]=1;
  }
  else if (x>=PASSAGE_WIDTH*5 && x<=PASSAGE_WIDTH*6
	   && y>=PASSAGE_WIDTH*3 && y<=PASSAGE_WIDTH*4
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[13]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[14]!=1){
      
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[14]=1;
  }
  else if (x>=PASSAGE_WIDTH*3 && x<=PASSAGE_WIDTH*4
	   && y>=PASSAGE_WIDTH*3 && y<=PASSAGE_WIDTH*4
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[14]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[15]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[15]=1;
  }
  else if (x>=PASSAGE_WIDTH*2 && x<=PASSAGE_WIDTH*3
	   && y>=PASSAGE_WIDTH*3 && y<=PASSAGE_WIDTH*4
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[15]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[16]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[16]=1;
  }
  else if (x>=PASSAGE_WIDTH*2 && x<=PASSAGE_WIDTH*3
	   && y>=PASSAGE_WIDTH*4 && y<=PASSAGE_WIDTH*5
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[16]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[17]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[17]=1;
  }
  else if (x>=PASSAGE_WIDTH*3 && x<=PASSAGE_WIDTH*4
	   && y>=PASSAGE_WIDTH*4 && y<=PASSAGE_WIDTH*5
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[17]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[18]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[18]=1;
  }
  else if (x>=PASSAGE_WIDTH*6 && x<=PASSAGE_WIDTH*7
	   && y>=PASSAGE_WIDTH*4 && y<=PASSAGE_WIDTH*5
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[18]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[19]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[19]=1;
  }
  else if (x>=PASSAGE_WIDTH*6 && x<=PASSAGE_WIDTH*7
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[19]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[20]!=1){
      
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[20]=1;
  }
  else if (x>=PASSAGE_WIDTH*5 && x<=PASSAGE_WIDTH*6
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[20]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[21]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[21]=1;
  }
  else if (x>=PASSAGE_WIDTH*5 && x<=PASSAGE_WIDTH*6
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[21]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[22]!=1){
      
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[22]=1;
  }
  else if (x>=PASSAGE_WIDTH*6 && x<=PASSAGE_WIDTH*7
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[22]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[23]!=1){
      
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[23]=1;
  }
  /**********************************************************************/
	else if (x>=PASSAGE_WIDTH*6 && x<=PASSAGE_WIDTH*7
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[23]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[24]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[24]=1;
  }
  else if (x>=PASSAGE_WIDTH*6 && x<=PASSAGE_WIDTH*7
	   && y>=PASSAGE_WIDTH*4 && y<=PASSAGE_WIDTH*5
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[24]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[25]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +30;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[25]=1;
  }
  else if (x>=PASSAGE_WIDTH*1 && x<=PASSAGE_WIDTH*2
	   && y>=PASSAGE_WIDTH*4 && y<=PASSAGE_WIDTH*5
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[25]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[26]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +50;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[26]=1;
  }
  else if (x>=PASSAGE_WIDTH*1 && x<=PASSAGE_WIDTH*2
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[26]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[27]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +50;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[27]=1;
  }
  else if (x>=PASSAGE_WIDTH*2 && x<=PASSAGE_WIDTH*3
	   && y>=PASSAGE_WIDTH*3 && y<=PASSAGE_WIDTH*4
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[27]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[28]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +50;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[28]=1;
  }
	else if (x>=PASSAGE_WIDTH*5 && x<=PASSAGE_WIDTH*6
	   && y>=PASSAGE_WIDTH*3 && y<=PASSAGE_WIDTH*4
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[28]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[29]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +50;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[29]=1;
  }
  else if (x>=PASSAGE_WIDTH*4 && x<=PASSAGE_WIDTH*5
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[29]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[30]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +50;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[30]=1;
  }
  else if (x>=PASSAGE_WIDTH*2 && x<=PASSAGE_WIDTH*3
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[30]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[31]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +50;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[31]=1;
  }
  else if (x>=PASSAGE_WIDTH*1 && x<=PASSAGE_WIDTH*2
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[31]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[32]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +50;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[32]=1;
	}
  /**********************************************************************/
  else if (x>=PASSAGE_WIDTH*0 && x<=PASSAGE_WIDTH*1
	   && y>=PASSAGE_WIDTH*4 && y<=PASSAGE_WIDTH*5
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[32]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[33]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] ;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[33]=1;
	}
  /**********************************************************************/
  else if (x>=PASSAGE_WIDTH*5 && x<=PASSAGE_WIDTH*6
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[34]!=1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[12]!=1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[40]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] -400;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[40]=1;
  }
  else if (x>=PASSAGE_WIDTH*1 && x<=PASSAGE_WIDTH*2
	   && y>=PASSAGE_WIDTH*3 && y<=PASSAGE_WIDTH*5
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[34]!=1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[25]!=1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[41]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] -400;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[41]=1;
  }
  else if (x>=PASSAGE_WIDTH*2 && x<=PASSAGE_WIDTH*3
	   && y>=PASSAGE_WIDTH*4 && y<=PASSAGE_WIDTH*5
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[34]!=1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[28]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[42]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] -400;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[42]=1;
  }
  else if (x>=PASSAGE_WIDTH*4 && x<=PASSAGE_WIDTH*5
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[34]!=1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[29]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[43]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] -400;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[43]=1;
  }
  else if (x>=PASSAGE_WIDTH*4 && x<=PASSAGE_WIDTH*5
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[34]!=1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[9]!=1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[44]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] -400;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[44]=1;
  }
  else if (x>=PASSAGE_WIDTH*6 && x<=PASSAGE_WIDTH*7
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[34]!=1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[21]!=1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[45]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] -400;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[45]=1;
  }
  else if (x>=PASSAGE_WIDTH*0 && x<=PASSAGE_WIDTH*1
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[34]!=1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[2]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[32]!=1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[46]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] -400;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[2]=0;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[46]=1;
  }
	else if (x>=PASSAGE_WIDTH*2 && x<=PASSAGE_WIDTH*3
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[34]!=1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[5]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[31]!=1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[47]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] -400;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[5]=0;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[47]=1;
  }
  else if (x>=PASSAGE_WIDTH*0 && x<=PASSAGE_WIDTH*1
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[34]!=1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[1]==1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[32]!=1
	   && AGENT[CNT_FAMILY].SUBGOAL_FLAG[48]!=1){
    
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] -400;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[2]=0;
    AGENT[CNT_FAMILY].SUBGOAL_FLAG[48]=1;
  }
  /**********************************************************************/

  if (AGENT[CNT_FAMILY].SUBGOAL_FLAG[33]==1
      && AGENT[CNT_FAMILY].SUBGOAL_FLAG[34]!=1){
    AGENT[CNT_FAMILY].SUCCESS++;
    AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] =AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT] +200;

    AGENT[CNT_FAMILY].SUBGOAL_FLAG[34]=1;

	AGENT[CNT_FAMILY].goal_flag=true; 

  }

	return;
  
}


void GaOperator(void){
	int i,j,k,g,f,e;
	int	sum,b,c,d,ind1,ind2;
	int fit[FAM_MAX],fit2[FAM_MAX];
	double dis;

	for (i=0;i<FAM_MAX;i++){
		/*for (k=0;k<=N_MAX-1;k++){
			for (g=0;g<=DIM_N-1;g++){
				AGENT[i].NEU_1[k][g]=0;
			}
		}*/
		for (k=0;k<SYN_MAX;k++){
			for (g=0;g<DIM_S;g++){
				AGENT[i].SYN_1[k][g]=0;
			}
		}
	}

	for (i=0;i<FAM_MAX;i++){
		fit[i]=AGENT[i].FITNESS;
	    fit2[i]=fit[i];
	}

	for (i=0;i<ELI_MAX;i++){
		ELI[i]=FAM_MAX-1;
	}
	for (i=0;i<ELI_MAX;i++){
		for (j=FAM_MAX-2;j>=0;j--){
			if(fit2[j]>=fit2[ELI[i]]){
				ELI[i]=j;
				ELI_FIT[i]=fit2[j];
			}
		}
		for (j=FAM_MAX-1;j>=0;j--){
			if (fit2[j]==fit2[ELI[i]])
				fit2[j]=1;
		}
	}

	for (i=0;i<ELI_MAX;i++){
		/*for (k=0;k<=N_MAX-1;k++){
			for (g=2;g<=DIM_N-1;g++){
				AGENT[i].NEU_1[k][g]
					=AGENT[ELI[i]].NEU[k][g];
			}
		}*/
		for (k=0;k<SYN_MAX;k++){
				AGENT[i].SYN_1[k][W_0]
					=AGENT[ELI[i]].SYN[k][W_0];
			//for (g=0;g<DIM_S-2;g++){
			//	AGENT[i].SYN_1[k][g]
			//		=AGENT[ELI[i]].SYN[k][g];
			//}
		}
	}

	sum=0;
	ind1=0;
	ind2=0;

	for (i=0;i<FAM_MAX;i++){
		sum=sum+fit[i];
	}
	for (i=ELI_MAX;i<FAM_MAX-NEW_MAX;i++){
		b=0;
		c=RandomInt(1,sum);
		for (d=0;d<FAM_MAX;d++){
			b=b+fit[d];
			if (c<=b){
				ind1=d;
				break;
			}
		}
	sel:;
		b=0;
		c=RandomInt(1,sum);
		for (d=0;d<FAM_MAX;d++){
			b=b+fit[d];
			if (c<=b){
				if (d==ind1){
					goto sel;
				}
				else{
					ind2=d;
					break;
				}
			}
		}
		/*for (k=0;k<=N_MAX-1;k++){
			if (RandomFloat()<=MUTATION_RATE){
				NEU_SET2(i,k);
			}
			else{
				for (g=2;g<=DIM_N-1;g++){
					//if (RandomFloat()<=M_PRO_2){
					//	NEU_SET3(i,k,g);
					//}
					//else {
						AGENT[i].NEU_1[k][g]
							=AGENT[ind1].NEU[k][g];
					//}
				}
			}
		}*/
		for (k=0;k<SYN_MAX;k++){
			if (RandomFloat()<=MUTATION_RATE){
				SYN_SET2(i,k);
			}
			else{
				AGENT[i].SYN_1[k][W_0]
							=AGENT[ind1].SYN[k][W_0];
				//for (g=0;g<DIM_S-2;g++){
					//if (RandomFloat()<=M_PRO_2){
					//	SYN_SET3(i,k,g);
					//}
					//else {
					//	AGENT[i].SYN_1[k][g]
					//		=AGENT[ind1].SYN[k][g];
					//}
				//}
			}
		}
		if (RandomFloat()<=CROSSOVER_RATE){
			/*e=RandomInt(0,N_MAX-1);
			f=RandomInt(e,N_MAX-1);
			for (k=e;k<=f;k++){
				if (RandomFloat()<=MUTATION_RATE){
					NEU_SET2(i,k);
				}
				else{
					c=2;
					d=DIM_N-1;
					for (g=c;g<=d;g++){
						//if (RandomFloat()<=M_PRO_2){
						//	NEU_SET3(i,k,g);
						//}
						//else {
							AGENT[i].NEU_1[k][g]
								=AGENT[ind2].NEU[k][g];
						//}
					}
				}
			}*/
			e=RandomInt(0,SYN_MAX-1);
			f=RandomInt(e,SYN_MAX-1);
			for (k=e;k<=f;k++){
				if (RandomFloat()<=MUTATION_RATE){
					SYN_SET2(i,k);
				}
				else{
					AGENT[i].SYN_1[k][W_0]
								=AGENT[ind2].SYN[k][W_0];
					//c=0;
					//d=DIM_S-2;
					//for (g=c;g<d;g++){
						//if (RandomFloat()<=M_PRO_2){
						//	SYN_SET3(i,k,g);
						//}
						//else {
					//		AGENT[i].SYN_1[k][g]
					//			=AGENT[ind2].SYN[k][g];
						//}
					//}
				}
			}
		}
	}
	for (i=FAM_MAX-NEW_MAX;i<FAM_MAX;i++){
		/*for (k=0;k<=N_MAX-1;k++){
			NEU_SET(i,k);
		}*/
	jp1:;
		for (k=0;k<SYN_MAX;k++){
			SYN_SET(i,k);
		}
		for (j=0;j<i;j++){
			dis=0;
			if (j<FAM_MAX-NEW_MAX){
				for (g=0;g<SYN_MAX;g++){	
					dis=dis+((AGENT[i].SYN[g][W_0]-AGENT[j].SYN_1[g][W_0])/(S_WEIGHT_MA-S_WEIGHT_MI))
							*((AGENT[i].SYN[g][W_0]-AGENT[j].SYN_1[g][W_0])/(S_WEIGHT_MA-S_WEIGHT_MI));
				}
			}
			else {
				for (g=0;g<SYN_MAX;g++){	
					dis=dis+((AGENT[i].SYN[g][W_0]-AGENT[j].SYN[g][W_0])/(S_WEIGHT_MA-S_WEIGHT_MI))
							*((AGENT[i].SYN[g][W_0]-AGENT[j].SYN[g][W_0])/(S_WEIGHT_MA-S_WEIGHT_MI));
				}
			}
			dis=sqrt(dis);
			if (dis<SAMPLE_DIS_MIN_INI){
				goto jp1;
			}
		}
		SetStructure(&AGENT[i]);
	}
  
	for (i=0;i<FAM_MAX-NEW_MAX;i++){
		/*for (k=0;k<=N_MAX-1;k++){
			for (g=2;g<=DIM_N-1;g++){
				AGENT[i].NEU[k][g]
					=AGENT[i].NEU_1[k][g];
			}
			AGENT[i].NEU[k][A_Y]=0;
			AGENT[i].NEU[k][A_X]=0;
		}*/
		for (k=0;k<SYN_MAX;k++){
			AGENT[i].SYN[k][W_0]=AGENT[i].SYN_1[k][W_0];
			//for (g=0;g<DIM_S-2;g++){
			//	AGENT[i].SYN[k][g]
			//		=AGENT[i].SYN_1[k][g];
			//}
		}
		SetStructure(&AGENT[i]);
	}
	return;
}

void GaPrintGeneration(void){
  
	int i,k,g;

	FILE *fp1;


	RESULT[CNT_TRIAL][CNT_GENERATION][0]=CNT_GENERATION;
	RESULT[CNT_TRIAL][CNT_GENERATION][1]=(double)AGENT[ELI[0]].FITNESS;
	for (i=0;i<ELI_MAX;i++){
		RESULT[CNT_TRIAL][CNT_GENERATION][2]+=(double)AGENT[ELI[i]].FITNESS;
	}
	RESULT[CNT_TRIAL][CNT_GENERATION][2]/=ELI_MAX;
	for (i=0;i<FAM_MAX;i++){
		RESULT[CNT_TRIAL][CNT_GENERATION][3]+=(double)AGENT[i].FITNESS;
	}
	RESULT[CNT_TRIAL][CNT_GENERATION][3]/=FAM_MAX;
	RESULT[CNT_TRIAL][CNT_GENERATION][4]=(double)AGENT[ELI[0]].SUCCESS;

	printf("\nTRI %d-%d-%d, GENERATION %4d, Elite_Best %d, Suc %d, Elite_Ave %7.3f, All_Ave %7.3f\n\n",
			CNT_TRIAL,CNT_SUCCESS,CNT_FALSE,
			CNT_GENERATION,AGENT[ELI[0]].FITNESS,(int)RESULT[CNT_TRIAL][CNT_GENERATION][4],
			RESULT[CNT_TRIAL][CNT_GENERATION][2],RESULT[CNT_TRIAL][CNT_GENERATION][3]);


	fopen_s(&fp1,"weight_binary.bin","wb"); /*����I�����̃j���[�����ƃV�i�v�X�̃f�[�^�o�C�i���ۑ��p*/
	for (i=0;i<FAM_MAX;i++){
		for (k=0;k<N_MAX;k++){
			for (g=0;g<DIM_N;g++){
				fwrite(&AGENT[i].NEU[k][g],sizeof(double),1,fp1);
			}
		}
		for (k=0;k<SYN_MAX;k++){
			for (g=0;g<DIM_S;g++){
				fwrite(&AGENT[i].SYN[k][g],sizeof(double),1,fp1);
			}
		}
	}
	fclose(fp1);

	return;

}

void GaPrintTrial(void){
  
	int i,j,k;
	char save_name[25];

	FILE *fp1;

	if (RESULT[CNT_TRIAL][GEN_MAX][4]>=REPEAT_MAX)
		CNT_SUCCESS++;
	else
		CNT_FALSE++;

	/**************************���̎��s�܂ł̌��ʏo��**************************/
	for(i=0;i<=GEN_MAX;i++){
		for (j=0;j<=4;j++){
			RESULT[0][i][j]=0;
		}
	}
	for(i=0;i<=GEN_MAX;i++){
		RESULT[0][i][0]=i;
		for (k=1;k<=CNT_TRIAL;k++){
			for (j=1;j<=4;j++){
				RESULT[0][i][j]+=RESULT[k][i][j];
			}
		}
		for (j=1;j<=4;j++){
			RESULT[0][i][j]/=(double)CNT_TRIAL;
		}		
	}

	fopen_s(&fp1,"result.txt","w");	
	for(i=0;i<=GEN_MAX;i++){
		for (k=0;k<=TRIAL_MAX;k++){
			for (j=0;j<=4;j++){
				fprintf(fp1," %f ",RESULT[k][i][j]);
			}
		}
		fprintf(fp1," \n ");
	}
	fclose(fp1);

	/*******���̎��s�̃j���[�����ƃV�i�v�X�̃f�[�^�o�C�i���ۑ�*****************/
	sprintf_s(save_name,"weight_binary%.2i.bin",CNT_TRIAL);
	fopen_s(&fp1,save_name,"wb");  
	for (i=0;i<FAM_MAX;i++){
		for (j=0;j<N_MAX;j++){
			for (k=0;k<DIM_N;k++){
				fwrite(&AGENT[i].NEU[j][k],sizeof(double),1,fp1);
			}
		}
		for (j=0;j<SYN_MAX;j++){
			for (k=0;k<DIM_S;k++){
				fwrite(&AGENT[i].SYN[j][k],sizeof(double),1,fp1);
			}
		}
	}
	fclose(fp1);   

	return;

}

void GaPrintEnd(void){
  
	int i,j,k;

	FILE *fp1;

	/**************************�S���s���ʏo��**************************/
	for(i=0;i<=GEN_MAX;i++){
		for (j=0;j<=4;j++){
			RESULT[0][i][j]=0;
		}
	}
	for(i=0;i<=GEN_MAX;i++){
		RESULT[0][i][0]=i;
		for (k=1;k<=TRIAL_MAX;k++){
			for (j=1;j<=4;j++){
				RESULT[0][i][j]+=RESULT[k][i][j];
			}
		}
		for (j=1;j<=4;j++){
			RESULT[0][i][j]/=(double)TRIAL_MAX;
		}		
	}

	fopen_s(&fp1,"result.txt","w");	
	for(i=0;i<=GEN_MAX;i++){
		for (k=0;k<=TRIAL_MAX;k++){
			for (j=0;j<=4;j++){
				fprintf(fp1," %f ",RESULT[k][i][j]);
			}
		}
		fprintf(fp1," \n ");
	}
	fclose(fp1);

	/**************************�S���s�̗����̎�o��**************************/
	fopen_s(&fp1,"seed.txt","w"); 
	fprintf(fp1," %d \n",seed);
	for (k=0;k<TRIAL_MAX;k++){
		fprintf(fp1," %d  %d \n",k+1,SEED[k]);
	}
	fclose(fp1);

	return;

}
