#include <ode/ode.h>
#include <drawstuff/drawstuff.h>
#include <math.h>
#include <stdlib.h>
#include <windows.h>


#include "parameter.h"
#include "main.h"
#include "EpuckModel.h"
#include "Environment.h"
#include "EpuckController.h"

#include "GeneticAlgorithm.h"
#include "MathFunction.h"

dWorldID world;  // ���͊w�v�Z�p���[���h
dSpaceID space;  // �Փˌ��o�p�X�y�[�X                                                   
dGeomID  ground; // �n��  
dJointGroupID contactgroup;     
dsFunctions fn;

int SIM_STEP;

static void command(int cmd);

static void nearCallback (void *data, dGeomID o1, dGeomID o2)
{
	int i,j,n;
	bool ray_flag;
	dBodyID b1 = dGeomGetBody(o1);
	dBodyID b2 = dGeomGetBody(o2);
	if (b1 && b2 && dAreConnectedExcluding(b1,b2,dJointTypeContact)) return;

	dContact contact[COLLIDE_MAX];
	
	n = dCollide(o1,o2,COLLIDE_MAX,&contact[0].geom,sizeof(dContact));

	if (n > 0) {	
		for (i=0; i<n; i++) {
			ray_flag=false;
			for (j=0; j<SUB_SENSOR_MAX; j++){
				if((o1==EPUCK.ir_sensor[j].ray || o2==EPUCK.ir_sensor[j].ray) 
					&& (o1!=EPUCK.base.geom && o2!=EPUCK.base.geom)){
					ray_flag=true;
					EPUCK.ir_sensor[j].collide_flag=true;
					EPUCK.ir_sensor[j].collide_pos[EPUCK.ir_sensor[j].collide_cnt][0]=contact[i].geom.pos[0];
					EPUCK.ir_sensor[j].collide_pos[EPUCK.ir_sensor[j].collide_cnt][1]=contact[i].geom.pos[1];
					EPUCK.ir_sensor[j].collide_pos[EPUCK.ir_sensor[j].collide_cnt][2]=contact[i].geom.pos[2];
					EPUCK.ir_sensor[j].collide_cnt++;
				}
			}

			for (j=0;j<WALL_MAX;j++){
				if((o1==ENVIRONMENT[j].geom || o2==ENVIRONMENT[j].geom) && (o1==EPUCK.base.geom || o2==EPUCK.base.geom)){
					EPUCK.collide_flag=true;
				}
			}
            if (ray_flag==false){
				contact[i].surface.mode = dContactSlip1 | dContactSlip2 |
									dContactSoftERP | dContactSoftCFM | dContactApprox1;
				contact[i].surface.mu       = NormalRandom(0.65, 0.65*DRIVE_NOISE_RANGE);//dInfinity; 
				if (contact[i].surface.mu<=0) contact[i].surface.mu=0.1;
				contact[i].surface.slip1    = 0.05f;//0.05
				contact[i].surface.slip2    = 0.05f;//0.05
				contact[i].surface.soft_erp = 0.6f;
				contact[i].surface.soft_cfm = (dReal)1e-10;
				dJointID c = dJointCreateContact(world,contactgroup,&contact[i]);
				dJointAttach(c,b1,b2);
			}
		}
	}
}

static void simLoop(int pause)
{
	
	SensorSet();
	dSpaceCollide (space,0,&nearCallback);
	dWorldStep (world,0.01f);
	dJointGroupEmpty (contactgroup);

	EpuckControll();
	
	if (DRAW){
		DrawRobot();
		DrawWall();
		//Sleep(10);
	}
}

static void start()
{
  float xyz[3] = {  1.0f, -4.0f, 5.0f};
  float hpr[3] = { 60.0f, -30.0f, 0.0f};

  dsSetViewpoint(xyz,hpr);
  dsSetSphereQuality(3);
}

static void setDrawStuff() 
{
  fn.version = DS_VERSION;
  fn.start   = &start;
  fn.step    = &simLoop;
  fn.command = &command;
  fn.path_to_textures = "textures";
}

static void command(int cmd)
{
 
}

int main(int argc, char *argv[])
{

	int i,j,k;

	setDrawStuff(); 
	dInitODE();
	world        = dWorldCreate();
	space        = dHashSpaceCreate(0);
	contactgroup = dJointGroupCreate(0);
	ground       = dCreatePlane(space,0,0,1,0);

	dWorldSetGravity(world, 0, 0, -98.0);

	CNT_FALSE=0;
	CNT_SUCCESS=0;
	for (i=0;i<=TRIAL_MAX;i++){
		for(j=0;j<=GEN_MAX;j++){
			for (k=0;k<=4;k++){
				RESULT[i][j][k]=0;
			}
		}
	}

	MakeRobot();
	MakeWall();

	srand(seed);

	CNT_TRIAL=1;

	SEED_TRIAL=RandomInt(1,RAND_MAX);
	SEED[CNT_TRIAL-1]=SEED_TRIAL;
	srand(SEED_TRIAL);

	GaInit();

	EpuckResetPosition();
  
	if (DRAW==true)
		dsSimulationLoop(argc,argv,800,600,&fn);
	else{
		while(1){
			simLoop(0);
		}
	}
	dSpaceDestroy(space);
	dWorldDestroy(world);
	dCloseODE(); 
	return 0;
}
