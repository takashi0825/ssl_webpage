#include <stdio.h>
#include <ode/ode.h>
#include "main.h"
#include "EpuckModel.h"
#include "EpuckController.h"
#include "Environment.h"
#include "MathFunction.h"

#include "NeuralNetwork.h"
#include "GeneticAlgorithm.h"

void EpuckControll(void){

	int ir_sensor_value[SENSOR_MAX];
	int i,j;
	double fit_ave,fit_div;

	/****************�Z���T�[************/
	GetIrSensorValue(ir_sensor_value);
	/***************************�ǏՓ˔���*************************/    
	for (j=0;j<SENSOR_MAX;j++){
		if(EPUCK.ir_sensor[j].value>=SENSOR_VALUE_MAX){
			EPUCK.collide_flag=true;
			break;
		}
	}
	/***************************�����܂�*************************/

	/****************�����܂�****************/

	if (SIM_STEP%TRANS_PERIOD==0){//PC�C���@�Ԃ̒ʐM����
		for (j=0;j<SENSOR_MAX;j++){
			EPUCK.ir_sensor[j].value=ir_sensor_value[j];
		}	
		/****************�j���[�����l�b�g���[�N*************/
		for (j=0;j<SENSOR_MAX;j++){
			AGENT[CNT_FAMILY].INPUT_NEU[j]=log((double)EPUCK.ir_sensor[j].value+1.0)/log(SENSOR_VALUE_MAX);
		}
		for (j=SENSOR_MAX;j<SENSOR_MAX+OUT_NEU;j++){
			AGENT[CNT_FAMILY].INPUT_NEU[j]=AGENT[CNT_FAMILY].OUTPUT_NEU[j-SENSOR_MAX];
		}

		NeuralNetwork(&(AGENT[CNT_FAMILY]));
		/****************�j���[�����l�b�g���[�N�����܂�*************/

		/****************�ړ�****************/

		if (SIM_STEP>100){
			//MoterControlLeftWall(ir_sensor_value,&(EPUCK.leftwheelspeed),&(EPUCK.rightwheelspeed));//���ǉ������[�^����
			EPUCK.leftwheelspeed=(dReal)(2.0*AGENT[CNT_FAMILY].OUTPUT_NEU[0]-1.0);
			EPUCK.rightwheelspeed=(dReal)(2.0*AGENT[CNT_FAMILY].OUTPUT_NEU[1]-1.0);
		}
		else {
			EPUCK.leftwheelspeed=0;
			EPUCK.rightwheelspeed=0;
		}
		ControlWheel((dReal)(2.0*PI*WHEEL_SPEED*EPUCK.leftwheelspeed),
					(dReal)(2.0*PI*WHEEL_SPEED*EPUCK.rightwheelspeed));

		if (EPUCK.leftwheelspeed<0 && EPUCK.rightwheelspeed<0){
			AGENT[CNT_FAMILY].output_sum=AGENT[CNT_FAMILY].output_sum
										-OUT_WEIGHT*(EPUCK.leftwheelspeed*EPUCK.rightwheelspeed)
										*log((double)EPUCK.ir_sensor[5].value+1.0)/log(SENSOR_VALUE_MAX);
		}
		else {
			AGENT[CNT_FAMILY].output_sum=AGENT[CNT_FAMILY].output_sum
										+OUT_WEIGHT*(EPUCK.leftwheelspeed*EPUCK.rightwheelspeed)
										*log((double)EPUCK.ir_sensor[5].value+1.0)/log(SENSOR_VALUE_MAX);
		}
	}

	/***************************1�X�e�b�v���Ƃ̕]���l�v�Z*************************/    
	EPUCK.pos = dBodyGetPosition(EPUCK.base.body);
	GaSubgoal(EPUCK.pos[0],PASSAGE_WIDTH*5-EPUCK.pos[1]);

	if(DRAW){
		printf("t:%5.2f[s], x:%4.3f[m], y:%4.3f[m], SG:%4d, OUT:%4.2f, FIT:%4d\n",
			    0.01*(float)SIM_STEP, 0.1*EPUCK.pos[0],  0.1*EPUCK.pos[1], AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT], AGENT[CNT_FAMILY].output_sum,
				AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT]+(int)AGENT[CNT_FAMILY].output_sum);
	}
	if (EPUCK.collide_flag==true){
		SIM_STEP=STEP_MAX;
	}
	if (((double)AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT]+AGENT[CNT_FAMILY].output_sum) <0 ){
		SIM_STEP=STEP_MAX;
	}    
	/***************************1�X�e�b�v���Ƃ̕]���l�v�Z�����܂�*************************/    


	SIM_STEP++;

	if (SIM_STEP>=STEP_MAX){   /*�K��X�e�b�v�ő��s�I��*/
		/***************************�K���x�Z�o*************************/    
		AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT]+=(int)AGENT[CNT_FAMILY].output_sum;
		/***************************�K���x�Z�o�����܂�*************************/    
		if(DRAW)
			printf("| %d %d |",AGENT[CNT_FAMILY].ENV_FIT[CNT_REPEAT],AGENT[CNT_FAMILY].SUCCESS);

		SIM_STEP=1;
		CNT_REPEAT++;
		AgentReset(CNT_FAMILY);
		EpuckResetPosition();
	}
	if (CNT_REPEAT>=REPEAT_MAX){
		AGENT[CNT_FAMILY].FITNESS=0;
		for(i=0;i<REPEAT_MAX;i++){
			AGENT[CNT_FAMILY].FITNESS=AGENT[CNT_FAMILY].FITNESS+AGENT[CNT_FAMILY].ENV_FIT[i];
		}
		fit_ave=(double)AGENT[CNT_FAMILY].FITNESS/REPEAT_MAX;
		fit_div=0;
		for(i=0;i<REPEAT_MAX;i++){
			fit_div=fit_div+(fit_ave-AGENT[CNT_FAMILY].ENV_FIT[i])*(fit_ave-AGENT[CNT_FAMILY].ENV_FIT[i]);
		}
		fit_div=sqrt(fit_div);
		AGENT[CNT_FAMILY].FITNESS=(int)(fit_ave-DIV_WEIGHT*fit_div);
		if (AGENT[CNT_FAMILY].FITNESS<1){
			AGENT[CNT_FAMILY].FITNESS=1;
		}
		if(DRAW)
			printf(" |FAM:%2d, FITNESS:%d, SUC:%2d |\n",CNT_FAMILY,AGENT[CNT_FAMILY].FITNESS,AGENT[CNT_FAMILY].SUCCESS);
		else
			printf(" |FAM:%2d, FITNESS:%d, SUC:%2d |",CNT_FAMILY,AGENT[CNT_FAMILY].FITNESS,AGENT[CNT_FAMILY].SUCCESS);


		CNT_REPEAT=0;
		CNT_FAMILY++;
	}
	if (CNT_FAMILY>=FAM_MAX){
		GaOperator();
		printf("\n");
		for (i=0;i<FAM_MAX;i++){
			printf("%d ",AGENT[i].FITNESS);
		}

		GaPrintGeneration();

		AgentResetFamily();
		CNT_FAMILY=0;
		CNT_GENERATION++;

	}
	if (CNT_GENERATION>GEN_MAX){

		GaPrintTrial();

		CNT_GENERATION=0;
		CNT_TRIAL++;

		if (CNT_TRIAL <= TRIAL_MAX){
			SEED_TRIAL=RandomInt(1,RAND_MAX);
			SEED[CNT_TRIAL-1]=SEED_TRIAL;
			srand(SEED_TRIAL);
			GaInit();
		}

	}
	if (CNT_TRIAL > TRIAL_MAX){

		GaPrintEnd();

		exit(0);
	}

}

void MoterControlLeftWall(int sensor_value[], dReal* leftwheel, dReal* rightwheel)
{

	int follow_weightleft[8] = {-10,-10,-5,0,0,5,10,10};
	int follow_weightright[8] = {10,10,5,0,0,-5,-10,-10};

	int i,gostraight;

	int value[8];

	gostraight=0;

	for (i=0; i<8; i++) {
		value[i]=sensor_value[i];
	}

	gostraight=1;
	for (i=0; i<8; i++) {
		if (value[i]>50) {
			gostraight=0;
			break;
		}
	}

	if (gostraight==0){
		*leftwheel=350;
		*rightwheel=350;
		follow_weightleft[0]=10;
		follow_weightleft[7]=10;
		follow_weightright[0]=-10;
		follow_weightright[7]=-10;
		if (value[5]>300) {
			value[4]-=100;
			value[5]-=200;
			value[6]-=200;
		}
		for (i=0; i<8; i++) {
			*leftwheel+=follow_weightleft[i]*(value[i]>>4);
			*rightwheel+=follow_weightright[i]*(value[i]>>4);
		}
	}
	else{
		*leftwheel=300;
		*rightwheel=700;
	}

	if (*leftwheel>800) *leftwheel=800;
	if (*leftwheel<-800) *leftwheel=-800;
	if (*rightwheel>800) *rightwheel=800;
	if (*rightwheel<-800) *rightwheel=-800;

	*leftwheel=*leftwheel/1000;
	*rightwheel=*rightwheel/1000;

	return;
}

void EpuckResetPosition(void){
	
	int i;
	dReal w1x = (dReal)BASE_r-0.095f;
	dReal w1z = - 0.005f;
	dMatrix3 R;
	dReal rnd_angle;

	rnd_angle= 0.0;
	//rnd_angle= (dReal)(M_PI/4.0*(ran_f()-0.5));
	
    dBodySetPosition(EPUCK.base2.body,(dReal)START_X2,(dReal)START_Y2,(dReal)START_Z2+BASE_l/2+BASE_l1+BASE_l2/2);
    dBodySetPosition(EPUCK.base1.body,(dReal)START_X1,(dReal)START_Y1,(dReal)START_Z1+BASE_l/2+BASE_l1/2);
	dBodySetPosition(EPUCK.base.body,(dReal)START_X,(dReal)START_Y,(dReal)START_Z);
	dBodySetPosition(EPUCK.wheel[0].body, -w1x+(dReal)START_X, (dReal)START_Y, w1z+(dReal)START_Z);  
	dBodySetPosition(EPUCK.wheel[1].body,  w1x+(dReal)START_X, (dReal)START_Y, w1z+(dReal)START_Z);
	/*dBodySetPosition(EPUCK.wheel[0].body, (dReal)START_X-w1x*cos(rnd_angle), 
										  (dReal)START_Y-w1x*sin(rnd_angle), w1z+(dReal)START_Z);  
	dBodySetPosition(EPUCK.wheel[1].body, (dReal)START_X+w1x*cos(rnd_angle), 
										  (dReal)START_Y+w1x*sin(rnd_angle), w1z+(dReal)START_Z); 
	*/
	dRFromAxisAndAngle(R,0,0,1,rnd_angle);
	dBodySetRotation(EPUCK.base.body,R);

	ControlWheel(0,0);

	for (i=0;i<SUB_SENSOR_MAX;i++){
			EPUCK.ir_sensor[i].value=0;
	}
	
	EPUCK.collide_flag=false;

	return;
}

