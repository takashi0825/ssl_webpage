void GaInit(void);
void AgentReset(int fam_num);
void AgentResetFamily(void);
void GaSubgoal(double x, double y);
void GaOperator(void);
void GaPrintGeneration(void);
void GaPrintTrial(void);
void GaPrintEnd(void);

 
