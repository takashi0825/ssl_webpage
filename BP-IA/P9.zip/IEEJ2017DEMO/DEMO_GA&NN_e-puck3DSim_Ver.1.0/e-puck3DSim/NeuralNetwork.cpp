#include "NeuralNetwork.h"
#include "main.h"
#include "MathFunction.h"

void NEU_SET(int fam,int num){
  AGENT[fam].NEU[num][A_Y]=0;
  AGENT[fam].NEU[num][A_X]=0;
  AGENT[fam].NEU[num][A_SITA]=0.1*(double)RandomInt((int)(SITA_MI*10),
						 (int)(SITA_MA*10));
  AGENT[fam].NEU[num][A_BETA]=0.1*(double)RandomInt((int)(BETA_MI*10),
						 (int)(BETA_MA*10));
  return;
}

void SYN_SET(int fam,int num){

  AGENT[fam].SYN[num][W_0]
    =0.01*(double)RandomInt((int)(S_WEIGHT_MI*100),(int)(S_WEIGHT_MA*100));

  return;  
}

void SYN_SET2(int fam,int num){
  
  AGENT[fam].SYN_1[num][W_0]
    =0.01*(double)RandomInt((int)(S_WEIGHT_MI*100),(int)(S_WEIGHT_MA*100));

  return;  
}

void SetStructure(struct Agent *ag){
	int i,j;

	for (i=0;i<IN_NEU;i++){
		for (j=0;j<H_NEURON;j++){
			ag->SYN[i*H_NEURON+j][PRE_N_J]=i;
			ag->SYN[i*H_NEURON+j][POS_N_I]=IN_NEU+j;
	    }
	}
	for (i=0;i<OUT_NEU;i++){	  
		for (j=0;j<H_NEURON;j++){
			ag->SYN[SYN_MAX-OUT_NEU*H_NEURON+i*H_NEURON+j][PRE_N_J]
				=N_MAX-OUT_NEU-H_NEURON+j;
			ag->SYN[SYN_MAX-OUT_NEU*H_NEURON+i*H_NEURON+j][POS_N_I]
				=N_MAX-OUT_NEU+i;
		}
	}
	return;
}

void NeuralNetwork(struct Agent* ag){

   int i,j,k;

  /**********************INPUT_NEURON****************************/
  for(i=0;i<IN_NEU;i++){
		ag->NEU[i][A_X]=ag->INPUT_NEU[i]-0.5;
		ag->NEU[i][A_Y]=2.0*SigmoidFunction(ag->NEU[i][A_X], ag->NEU[i][A_BETA], ag->NEU[i][A_SITA])-1.0;
  }
  /************************************************************/

  for (i=0;i<IN_NEU*H_NEURON;i++){
    j=(int)ag->SYN[i][POS_N_I];
    k=(int)ag->SYN[i][PRE_N_J];
    
    ag->NEU[j][A_X] = ag->NEU[j][A_X] + ag->SYN[i][W_0]*ag->NEU[k][A_Y];
  }

  for (i=IN_NEU;i<IN_NEU+H_NEURON;i++){
    ag->NEU[i][A_Y] = SigmoidFunction(ag->NEU[i][A_X], ag->NEU[i][A_BETA], ag->NEU[i][A_SITA]);
  }

  for (i=IN_NEU*H_NEURON;i<SYN_MAX;i++){
    j=(int)ag->SYN[i][POS_N_I];
    k=(int)ag->SYN[i][PRE_N_J];
    
    ag->NEU[j][A_X] = ag->NEU[j][A_X] + ag->SYN[i][W_0]*ag->NEU[k][A_Y];
  }

  for (i=IN_NEU+H_NEURON;i<N_MAX;i++){
    ag->NEU[i][A_Y] = SigmoidFunction(ag->NEU[i][A_X], ag->NEU[i][A_BETA], ag->NEU[i][A_SITA]);
  }
  
  /*************************************************************/ 

  for (i=N_MAX-OUT_NEU;i<N_MAX;i++){
	  ag->OUTPUT_NEU[i-N_MAX+OUT_NEU]=ag->NEU[i][A_Y];
  }    

  for (i=0;i<N_MAX;i++){
	  ag->NEU[i][A_X]=0;
	  ag->NEU[i][A_Y]=0;
  }    

  return;
}





