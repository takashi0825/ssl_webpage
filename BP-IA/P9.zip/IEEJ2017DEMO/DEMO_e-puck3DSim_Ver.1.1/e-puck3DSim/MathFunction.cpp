#include "MathFunction.h"
#include "main.h"

double GaussianFunction(double x,double y){

	double i;
	i=0.0;
	i=1.0/y*exp(-x*x/(2*y*y));

	return i;
}

double SigmoidFunction(double x,double beta,double theta){
	
	double i;
    i=0.0;
	i=1.0/(1.0+exp(-beta*(x-theta)));
    
	return i;
}

double NormalRandom(double mean, double sigma){	

	/* Box-Muller method */

	double u1 = 0.0;
	double u2 = 0.0; 
	double g = 0.0;
	double r;
		
	u1 = (double)rand()/RAND_MAX;
	while( u1 == 0.0 ){
		u1 = (double)rand()/RAND_MAX;
	}
	u2 = (double)rand()/RAND_MAX;
		
	g = sqrt(-2.0*log(u1)) * cos(2.0*PI*u2);
		
	r = sigma * g + mean;
			
	return r;
}

double RandomFloat(){

	double f;

	f=0.0;
	f=(double)(rand())/(double)RAND_MAX;

	return f;
}

int RandomInt(int a,int b){

	float f;

	f=0;
	f=(float)(rand())/RAND_MAX*(RAND_MAX-1)/RAND_MAX;
	f=f*(float)(b-a+1)+a;

	return (int)f;
}
