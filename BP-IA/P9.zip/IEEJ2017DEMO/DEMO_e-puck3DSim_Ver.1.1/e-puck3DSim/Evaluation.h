void EvaluationReset(void);
void EvaluationSubgoal(double x, double y);

 
