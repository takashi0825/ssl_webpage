
void EpuckControll(void);
void MoterControlLeftWall(int sensor_value[], dReal* leftwheel, dReal* rightwheel);
void EpuckSetPosition(void);
void EpuckResetPosition(void);
