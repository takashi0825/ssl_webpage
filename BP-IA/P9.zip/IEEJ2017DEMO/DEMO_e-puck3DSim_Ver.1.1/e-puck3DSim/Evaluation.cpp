#include "Evaluation.h"
#include "main.h"
#include "MathFunction.h"

struct Agent AGENT;

void EvaluationReset(void){

	int i;

	AGENT.goal_flag=false;
	AGENT.end_flag=false;
	AGENT.left_wall_flag=false;
	AGENT.output_sum=0.0;
	for (i=0;i<SUBGOAL;i++){
		AGENT.SUBGOAL_FLAG[i]=0;
	}
	AGENT.E_value=S_VALUE;

	return;
}

void EvaluationSubgoal(double x, double y){

  /**********************************************************************/
  if (x>=PASSAGE_WIDTH*0 && x<=PASSAGE_WIDTH*0.5
      && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
      //&& y>=PASSAGE_WIDTH*3 && y<=PASSAGE_WIDTH*4
      && AGENT.SUBGOAL_FLAG[0]!=1){
    
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[0]=1;
  }
  else if (x>=PASSAGE_WIDTH*0 && x<=PASSAGE_WIDTH*0.5
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT.SUBGOAL_FLAG[0]==1
	   && AGENT.SUBGOAL_FLAG[1]!=1){
    
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[1]=1;
  }
  else if (x>=PASSAGE_WIDTH*1 && x<=PASSAGE_WIDTH*2
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT.SUBGOAL_FLAG[1]==1
	   && AGENT.SUBGOAL_FLAG[2]!=1){
    
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[2]=1;
    AGENT.SUBGOAL_FLAG[46]=0;
    AGENT.SUBGOAL_FLAG[48]=0;
  }
  else if (x>=PASSAGE_WIDTH*1 && x<=PASSAGE_WIDTH*2
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*0.5
	   && AGENT.SUBGOAL_FLAG[2]==1
	   && AGENT.SUBGOAL_FLAG[3]!=1){
    
    AGENT.E_value =AGENT.E_value +30;
      AGENT.SUBGOAL_FLAG[3]=1;
  }
  else if (x>=PASSAGE_WIDTH*2 && x<=PASSAGE_WIDTH*3
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*1
	   && AGENT.SUBGOAL_FLAG[3]==1
	   && AGENT.SUBGOAL_FLAG[4]!=1){
      
      AGENT.E_value =AGENT.E_value +30;
      AGENT.SUBGOAL_FLAG[4]=1;
  }
  else if (x>=PASSAGE_WIDTH*2 && x<=PASSAGE_WIDTH*3 
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT.SUBGOAL_FLAG[4]==1
	   && AGENT.SUBGOAL_FLAG[5]!=1){

    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[5]=1;
    AGENT.SUBGOAL_FLAG[47]=0;
  }
  else if (x>=PASSAGE_WIDTH*4 && x<=PASSAGE_WIDTH*5 
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT.SUBGOAL_FLAG[5]==1
	   && AGENT.SUBGOAL_FLAG[6]!=1){
     
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[6]=1;
  }
  else if (x>=PASSAGE_WIDTH*4 && x<=PASSAGE_WIDTH*5 
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT.SUBGOAL_FLAG[6]==1
	   && AGENT.SUBGOAL_FLAG[7]!=1){
    
      AGENT.E_value =AGENT.E_value +30;
      AGENT.SUBGOAL_FLAG[7]=1;
  }
  else if (x>=PASSAGE_WIDTH*3 && x<=PASSAGE_WIDTH*4 
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT.SUBGOAL_FLAG[7]==1
	   && AGENT.SUBGOAL_FLAG[8]!=1){

    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[8]=1;      
  }
  else if (x>=PASSAGE_WIDTH*3 && x<=PASSAGE_WIDTH*4
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*1
	   && AGENT.SUBGOAL_FLAG[8]==1
	   && AGENT.SUBGOAL_FLAG[9]!=1){
    
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[9]=1;
  }
  else if (x>=PASSAGE_WIDTH*4 && x<=PASSAGE_WIDTH*5
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*1
	   && AGENT.SUBGOAL_FLAG[9]==1
	   && AGENT.SUBGOAL_FLAG[10]!=1){
      
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[10]=1;
  }
  else if (x>=PASSAGE_WIDTH*4 && x<=PASSAGE_WIDTH*5
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT.SUBGOAL_FLAG[10]==1
	   && AGENT.SUBGOAL_FLAG[11]!=1){
      
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[11]=1;
  }
  else if (x>=PASSAGE_WIDTH*4 && x<=PASSAGE_WIDTH*5
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT.SUBGOAL_FLAG[11]==1
	   && AGENT.SUBGOAL_FLAG[12]!=1){
    
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[12]=1;
  }
  else if (x>=PASSAGE_WIDTH*5 && x<=PASSAGE_WIDTH*6
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT.SUBGOAL_FLAG[12]==1
	   && AGENT.SUBGOAL_FLAG[13]!=1){
      
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[13]=1;
  }
  else if (x>=PASSAGE_WIDTH*5 && x<=PASSAGE_WIDTH*6
	   && y>=PASSAGE_WIDTH*3 && y<=PASSAGE_WIDTH*4
	   && AGENT.SUBGOAL_FLAG[13]==1
	   && AGENT.SUBGOAL_FLAG[14]!=1){
      
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[14]=1;
  }
  else if (x>=PASSAGE_WIDTH*3 && x<=PASSAGE_WIDTH*4
	   && y>=PASSAGE_WIDTH*3 && y<=PASSAGE_WIDTH*4
	   && AGENT.SUBGOAL_FLAG[14]==1
	   && AGENT.SUBGOAL_FLAG[15]!=1){
    
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[15]=1;
  }
  else if (x>=PASSAGE_WIDTH*2 && x<=PASSAGE_WIDTH*3
	   && y>=PASSAGE_WIDTH*3 && y<=PASSAGE_WIDTH*4
	   && AGENT.SUBGOAL_FLAG[15]==1
	   && AGENT.SUBGOAL_FLAG[16]!=1){
    
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[16]=1;
  }
  else if (x>=PASSAGE_WIDTH*2 && x<=PASSAGE_WIDTH*3
	   && y>=PASSAGE_WIDTH*4 && y<=PASSAGE_WIDTH*5
	   && AGENT.SUBGOAL_FLAG[16]==1
	   && AGENT.SUBGOAL_FLAG[17]!=1){
    
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[17]=1;
  }
  else if (x>=PASSAGE_WIDTH*3 && x<=PASSAGE_WIDTH*4
	   && y>=PASSAGE_WIDTH*4 && y<=PASSAGE_WIDTH*5
	   && AGENT.SUBGOAL_FLAG[17]==1
	   && AGENT.SUBGOAL_FLAG[18]!=1){
    
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[18]=1;
  }
  else if (x>=PASSAGE_WIDTH*6 && x<=PASSAGE_WIDTH*7
	   && y>=PASSAGE_WIDTH*4 && y<=PASSAGE_WIDTH*5
	   && AGENT.SUBGOAL_FLAG[18]==1
	   && AGENT.SUBGOAL_FLAG[19]!=1){
    
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[19]=1;
  }
  else if (x>=PASSAGE_WIDTH*6 && x<=PASSAGE_WIDTH*7
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT.SUBGOAL_FLAG[19]==1
	   && AGENT.SUBGOAL_FLAG[20]!=1){
      
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[20]=1;
  }
  else if (x>=PASSAGE_WIDTH*5 && x<=PASSAGE_WIDTH*6
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT.SUBGOAL_FLAG[20]==1
	   && AGENT.SUBGOAL_FLAG[21]!=1){
    
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[21]=1;
  }
  else if (x>=PASSAGE_WIDTH*5 && x<=PASSAGE_WIDTH*6
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*1
	   && AGENT.SUBGOAL_FLAG[21]==1
	   && AGENT.SUBGOAL_FLAG[22]!=1){
      
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[22]=1;
  }
  else if (x>=PASSAGE_WIDTH*6 && x<=PASSAGE_WIDTH*7
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*1
	   && AGENT.SUBGOAL_FLAG[22]==1
	   && AGENT.SUBGOAL_FLAG[23]!=1){
      
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[23]=1;
  }
  /**********************************************************************/
	else if (x>=PASSAGE_WIDTH*6 && x<=PASSAGE_WIDTH*7
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT.SUBGOAL_FLAG[23]==1
	   && AGENT.SUBGOAL_FLAG[24]!=1){
    
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[24]=1;
  }
  else if (x>=PASSAGE_WIDTH*6 && x<=PASSAGE_WIDTH*7
	   && y>=PASSAGE_WIDTH*4 && y<=PASSAGE_WIDTH*5
	   && AGENT.SUBGOAL_FLAG[24]==1
	   && AGENT.SUBGOAL_FLAG[25]!=1){
    
    AGENT.E_value =AGENT.E_value +30;
    AGENT.SUBGOAL_FLAG[25]=1;
  }
  else if (x>=PASSAGE_WIDTH*1 && x<=PASSAGE_WIDTH*2
	   && y>=PASSAGE_WIDTH*4 && y<=PASSAGE_WIDTH*5
	   && AGENT.SUBGOAL_FLAG[25]==1
	   && AGENT.SUBGOAL_FLAG[26]!=1){
    
    AGENT.E_value =AGENT.E_value +50;
    AGENT.SUBGOAL_FLAG[26]=1;
  }
  else if (x>=PASSAGE_WIDTH*1 && x<=PASSAGE_WIDTH*2
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT.SUBGOAL_FLAG[26]==1
	   && AGENT.SUBGOAL_FLAG[27]!=1){
    
    AGENT.E_value =AGENT.E_value +50;
    AGENT.SUBGOAL_FLAG[27]=1;
  }
  else if (x>=PASSAGE_WIDTH*2 && x<=PASSAGE_WIDTH*3
	   && y>=PASSAGE_WIDTH*3 && y<=PASSAGE_WIDTH*4
	   && AGENT.SUBGOAL_FLAG[27]==1
	   && AGENT.SUBGOAL_FLAG[28]!=1){
    
    AGENT.E_value =AGENT.E_value +50;
    AGENT.SUBGOAL_FLAG[28]=1;
  }
	else if (x>=PASSAGE_WIDTH*5 && x<=PASSAGE_WIDTH*6
	   && y>=PASSAGE_WIDTH*3 && y<=PASSAGE_WIDTH*4
	   && AGENT.SUBGOAL_FLAG[28]==1
	   && AGENT.SUBGOAL_FLAG[29]!=1){
    
    AGENT.E_value =AGENT.E_value +50;
    AGENT.SUBGOAL_FLAG[29]=1;
  }
  else if (x>=PASSAGE_WIDTH*4 && x<=PASSAGE_WIDTH*5
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT.SUBGOAL_FLAG[29]==1
	   && AGENT.SUBGOAL_FLAG[30]!=1){
    
    AGENT.E_value =AGENT.E_value +50;
    AGENT.SUBGOAL_FLAG[30]=1;
  }
  else if (x>=PASSAGE_WIDTH*2 && x<=PASSAGE_WIDTH*3
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT.SUBGOAL_FLAG[30]==1
	   && AGENT.SUBGOAL_FLAG[31]!=1){
    
    AGENT.E_value =AGENT.E_value +50;
    AGENT.SUBGOAL_FLAG[31]=1;
  }
  else if (x>=PASSAGE_WIDTH*1 && x<=PASSAGE_WIDTH*2
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT.SUBGOAL_FLAG[31]==1
	   && AGENT.SUBGOAL_FLAG[32]!=1){
    
    AGENT.E_value =AGENT.E_value +50;
    AGENT.SUBGOAL_FLAG[32]=1;
	}
  /**********************************************************************/
  else if (x>=PASSAGE_WIDTH*0 && x<=PASSAGE_WIDTH*1
	   && y>=PASSAGE_WIDTH*4 && y<=PASSAGE_WIDTH*5
	   && AGENT.SUBGOAL_FLAG[32]==1
	   && AGENT.SUBGOAL_FLAG[33]!=1){
    
    AGENT.E_value =AGENT.E_value ;
    AGENT.SUBGOAL_FLAG[33]=1;
	}
  /**********************************************************************/
  else if (x>=PASSAGE_WIDTH*5 && x<=PASSAGE_WIDTH*6
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT.SUBGOAL_FLAG[34]!=1
	   && AGENT.SUBGOAL_FLAG[12]!=1
	   && AGENT.SUBGOAL_FLAG[40]!=1){
    
    AGENT.E_value =AGENT.E_value -400;
    AGENT.SUBGOAL_FLAG[40]=1;
  }
  else if (x>=PASSAGE_WIDTH*1 && x<=PASSAGE_WIDTH*2
	   && y>=PASSAGE_WIDTH*3 && y<=PASSAGE_WIDTH*5
	   && AGENT.SUBGOAL_FLAG[34]!=1
	   && AGENT.SUBGOAL_FLAG[25]!=1
	   && AGENT.SUBGOAL_FLAG[41]!=1){
    
    AGENT.E_value =AGENT.E_value -400;
    AGENT.SUBGOAL_FLAG[41]=1;
  }
  else if (x>=PASSAGE_WIDTH*2 && x<=PASSAGE_WIDTH*3
	   && y>=PASSAGE_WIDTH*4 && y<=PASSAGE_WIDTH*5
	   && AGENT.SUBGOAL_FLAG[34]!=1
	   && AGENT.SUBGOAL_FLAG[28]==1
	   && AGENT.SUBGOAL_FLAG[42]!=1){
    
    AGENT.E_value =AGENT.E_value -400;
    AGENT.SUBGOAL_FLAG[42]=1;
  }
  else if (x>=PASSAGE_WIDTH*4 && x<=PASSAGE_WIDTH*5
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT.SUBGOAL_FLAG[34]!=1
	   && AGENT.SUBGOAL_FLAG[29]==1
	   && AGENT.SUBGOAL_FLAG[43]!=1){
    
    AGENT.E_value =AGENT.E_value -400;
    AGENT.SUBGOAL_FLAG[43]=1;
  }
  else if (x>=PASSAGE_WIDTH*4 && x<=PASSAGE_WIDTH*5
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*1
	   && AGENT.SUBGOAL_FLAG[34]!=1
	   && AGENT.SUBGOAL_FLAG[9]!=1
	   && AGENT.SUBGOAL_FLAG[44]!=1){
    
    AGENT.E_value =AGENT.E_value -400;
    AGENT.SUBGOAL_FLAG[44]=1;
  }
  else if (x>=PASSAGE_WIDTH*6 && x<=PASSAGE_WIDTH*7
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*1
	   && AGENT.SUBGOAL_FLAG[34]!=1
	   && AGENT.SUBGOAL_FLAG[21]!=1
	   && AGENT.SUBGOAL_FLAG[45]!=1){
    
    AGENT.E_value =AGENT.E_value -400;
    AGENT.SUBGOAL_FLAG[45]=1;
  }
  else if (x>=PASSAGE_WIDTH*0 && x<=PASSAGE_WIDTH*1
	   && y>=PASSAGE_WIDTH*1 && y<=PASSAGE_WIDTH*2
	   && AGENT.SUBGOAL_FLAG[34]!=1
	   && AGENT.SUBGOAL_FLAG[2]==1
	   && AGENT.SUBGOAL_FLAG[32]!=1
	   && AGENT.SUBGOAL_FLAG[46]!=1){
    
    AGENT.E_value =AGENT.E_value -400;
    AGENT.SUBGOAL_FLAG[2]=0;
    AGENT.SUBGOAL_FLAG[46]=1;
  }
	else if (x>=PASSAGE_WIDTH*2 && x<=PASSAGE_WIDTH*3
	   && y>=PASSAGE_WIDTH*0 && y<=PASSAGE_WIDTH*1
	   && AGENT.SUBGOAL_FLAG[34]!=1
	   && AGENT.SUBGOAL_FLAG[5]==1
	   && AGENT.SUBGOAL_FLAG[31]!=1
	   && AGENT.SUBGOAL_FLAG[47]!=1){
    
    AGENT.E_value =AGENT.E_value -400;
    AGENT.SUBGOAL_FLAG[5]=0;
    AGENT.SUBGOAL_FLAG[47]=1;
  }
  else if (x>=PASSAGE_WIDTH*0 && x<=PASSAGE_WIDTH*1
	   && y>=PASSAGE_WIDTH*2 && y<=PASSAGE_WIDTH*3
	   && AGENT.SUBGOAL_FLAG[34]!=1
	   && AGENT.SUBGOAL_FLAG[1]==1
	   && AGENT.SUBGOAL_FLAG[32]!=1
	   && AGENT.SUBGOAL_FLAG[48]!=1){
    
    AGENT.E_value =AGENT.E_value -400;
    AGENT.SUBGOAL_FLAG[2]=0;
    AGENT.SUBGOAL_FLAG[48]=1;
  }
  /**********************************************************************/

  if (AGENT.SUBGOAL_FLAG[33]==1
      && AGENT.SUBGOAL_FLAG[34]!=1){
    AGENT.E_value =AGENT.E_value +200;
	AGENT.goal_flag=true; 
    AGENT.SUBGOAL_FLAG[34]=1;
  }

	return;
  
}


