void MakeRobot();
void DrawRobot();
void ControlWheel(dReal right, dReal left);
void SensorSet(void);
void GetIrSensorValue(int *sensor);
int GaussApp(double x1,double x2,double x3);