#include "main.h"

struct Environment ENVIRONMENT[WALL_MAX];

void MakeWall() {

	int i;
	dMass m[WALL_MAX];
	dReal wall_mass[WALL_MAX];

	/********************�ǂ̈ʒu*******************************/

	for (i=0;i<WALL_MAX;i++){
		ENVIRONMENT[i].wall_pos[2] = WALL_POS_Z;
	}

	ENVIRONMENT[0].wall_pos[0] = 0;
	ENVIRONMENT[0].wall_pos[1] = PASSAGE_WIDTH*2.5;
	ENVIRONMENT[0].wall_pos[2] = 0.3;

	ENVIRONMENT[1].wall_pos[0] = PASSAGE_WIDTH*7;
	ENVIRONMENT[1].wall_pos[1] = PASSAGE_WIDTH*2.5;

	ENVIRONMENT[2].wall_pos[0] = PASSAGE_WIDTH*1;
	ENVIRONMENT[2].wall_pos[1] = PASSAGE_WIDTH*4.5f-0.0251f;

	ENVIRONMENT[3].wall_pos[0] = PASSAGE_WIDTH*1;
	ENVIRONMENT[3].wall_pos[1] = PASSAGE_WIDTH*1.5+0.0251f;

	ENVIRONMENT[4].wall_pos[0] = PASSAGE_WIDTH*2;
	ENVIRONMENT[4].wall_pos[1] = PASSAGE_WIDTH*3;

	ENVIRONMENT[5].wall_pos[0] = PASSAGE_WIDTH*3;
	ENVIRONMENT[5].wall_pos[1] = PASSAGE_WIDTH*4-0.0251f;

	ENVIRONMENT[6].wall_pos[0] = PASSAGE_WIDTH*5;
	ENVIRONMENT[6].wall_pos[1] = PASSAGE_WIDTH*4-0.0251f;

	ENVIRONMENT[7].wall_pos[0] = PASSAGE_WIDTH*6;
	ENVIRONMENT[7].wall_pos[1] = PASSAGE_WIDTH*2;

	ENVIRONMENT[8].wall_pos[0] = PASSAGE_WIDTH*3.5f;
	ENVIRONMENT[8].wall_pos[1] = PASSAGE_WIDTH*5;

	ENVIRONMENT[9].wall_pos[0] = PASSAGE_WIDTH*3.5f;
	ENVIRONMENT[9].wall_pos[1] = 0;
	
	ENVIRONMENT[10].wall_pos[0] = PASSAGE_WIDTH*0.5;
	ENVIRONMENT[10].wall_pos[1] = PASSAGE_WIDTH*4;

	ENVIRONMENT[11].wall_pos[0] = PASSAGE_WIDTH*1.5;
	ENVIRONMENT[11].wall_pos[1] = PASSAGE_WIDTH*3;

	ENVIRONMENT[12].wall_pos[0] = PASSAGE_WIDTH*3.5f;
	ENVIRONMENT[12].wall_pos[1] = PASSAGE_WIDTH*2;

	ENVIRONMENT[13].wall_pos[0] = PASSAGE_WIDTH*3.5f;
	ENVIRONMENT[13].wall_pos[1] = PASSAGE_WIDTH*3;

	ENVIRONMENT[14].wall_pos[0] = PASSAGE_WIDTH*5.5f;
	ENVIRONMENT[14].wall_pos[1] = PASSAGE_WIDTH*3;

	ENVIRONMENT[15].wall_pos[0] = PASSAGE_WIDTH*4.5f;
	ENVIRONMENT[15].wall_pos[1] = PASSAGE_WIDTH*1;


	/*******************�ǂ̒���(X,Y,Z)********************/
	for (i=0;i<8;i++){
		ENVIRONMENT[i].wall_size[0] = 0.03f;
		ENVIRONMENT[i].wall_size[2] = 0.50f;
	}
	ENVIRONMENT[0].wall_size[1] = PASSAGE_WIDTH*5+0.05f;	//�ǂ̒���(X,Y,Z)�c��5����
	ENVIRONMENT[1].wall_size[1] = PASSAGE_WIDTH*5+0.05f;	//�ǂ̒���(X,Y,Z)�c��5����
	ENVIRONMENT[2].wall_size[1] = PASSAGE_WIDTH*1+0.00f;	//�ǂ̒���(X,Y,Z)�c��1����
	ENVIRONMENT[3].wall_size[1] = PASSAGE_WIDTH*3-0.00f;	//�ǂ̒���(X,Y,Z)�c��3����
	ENVIRONMENT[4].wall_size[1] = PASSAGE_WIDTH*2+0.05f;	//�ǂ̒���(X,Y,Z)�c��2����
	ENVIRONMENT[5].wall_size[1] = PASSAGE_WIDTH*2+0.00f;	//�ǂ̒���(X,Y,Z)�c��2����
	ENVIRONMENT[6].wall_size[1] = PASSAGE_WIDTH*2+0.00f;	//�ǂ̒���(X,Y,Z)�c��2����
	ENVIRONMENT[7].wall_size[1] = PASSAGE_WIDTH*2+0.05f;	//�ǂ̒���(X,Y,Z)�c��2����

	for (i=8;i<WALL_MAX;i++){
		ENVIRONMENT[i].wall_size[1] = 0.03f;
		ENVIRONMENT[i].wall_size[2] = 0.50f;
	}
	ENVIRONMENT[8].wall_size[0] = PASSAGE_WIDTH*7-0.06f;	//�ǂ̒���(X,Y,Z)����7����
	ENVIRONMENT[9].wall_size[0] = PASSAGE_WIDTH*7-0.06f;	//�ǂ̒���(X,Y,Z)����7����
	ENVIRONMENT[10].wall_size[0] = PASSAGE_WIDTH*1-0.06f;	//�ǂ̒���(X,Y,Z)����1����
	ENVIRONMENT[11].wall_size[0] = PASSAGE_WIDTH*1-0.06f;	//�ǂ̒���(X,Y,Z)����1����
	ENVIRONMENT[12].wall_size[0] = PASSAGE_WIDTH*3-0.06f;	//�ǂ̒���(X,Y,Z)����3����
	ENVIRONMENT[13].wall_size[0] = PASSAGE_WIDTH*1-0.06f;	//�ǂ̒���(X,Y,Z)����1����
	ENVIRONMENT[14].wall_size[0] = PASSAGE_WIDTH*1-0.06f;	//�ǂ̒���(X,Y,Z)����1����
	ENVIRONMENT[15].wall_size[0] = PASSAGE_WIDTH*3-0.06f;	//�ǂ̒���(X,Y,Z)����3����

	for (i=0;i<WALL_MAX;i++){
		wall_mass[i]=0.45f;
		ENVIRONMENT[i].body = dBodyCreate(world);
	  
		dMassSetZero(&m[i]);
		dMassSetBoxTotal(&m[i],wall_mass[i],ENVIRONMENT[i].wall_size[0],ENVIRONMENT[i].wall_size[1],ENVIRONMENT[i].wall_size[2]);
		dMassAdjust(&m[i],wall_mass[i]);
		dBodySetMass(ENVIRONMENT[i].body,&m[i]);
 
		ENVIRONMENT[i].geom = dCreateBox(space,ENVIRONMENT[i].wall_size[0],ENVIRONMENT[i].wall_size[1],ENVIRONMENT[i].wall_size[2]);
		dGeomSetBody(ENVIRONMENT[i].geom,ENVIRONMENT[i].body);
		dBodySetPosition(ENVIRONMENT[i].body,ENVIRONMENT[i].wall_pos[0],ENVIRONMENT[i].wall_pos[1],ENVIRONMENT[i].wall_pos[2]);
	}

	for (i=0;i<WALL_MAX;i++){
		ENVIRONMENT[i].wall_floor_joint = dJointCreateFixed(world, 0);	// �Œ�֐߁i�y��ƒn�ʂ̌Œ�j
		dJointAttach(ENVIRONMENT[i].wall_floor_joint, ENVIRONMENT[i].body, 0);	// �Œ�֐߂̎�t��
		dJointSetFixed(ENVIRONMENT[i].wall_floor_joint);   
	}

}

void DrawWall()
{
 
	int i;

	for(i=0;i<WALL_MAX;i++){
		dsSetColorAlpha(1.0f,1.0f,0.4f,1.0f);
		dsDrawBox(dGeomGetPosition(ENVIRONMENT[i].geom),
				  dGeomGetRotation(ENVIRONMENT[i].geom),&ENVIRONMENT[i].wall_size[0]);
	}

}
