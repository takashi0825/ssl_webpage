double GaussianFunction(double x,double y);
double SigmoidFunction(double x,double beta,double theta);
double NormalRandom(double mean, double sigma);
double RandomFloat();
int RandomInt(int a,int b);
