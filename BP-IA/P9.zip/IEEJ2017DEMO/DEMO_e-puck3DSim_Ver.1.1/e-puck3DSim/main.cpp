#include <ode/ode.h>
#include <drawstuff/drawstuff.h>
#include <math.h>
#include <stdlib.h>

#include "Parameter.h"
#include "main.h"
#include "EpuckModel.h"
#include "Environment.h"
#include "EpuckController.h"

#include "Evaluation.h"
#include "MathFunction.h"

dWorldID world;  // ���͊w�v�Z�p���[���h
dSpaceID space;  // �Փˌ��o�p�X�y�[�X                                                   
dGeomID  ground; // �n��  
dJointGroupID contactgroup;     
dsFunctions fn;

int SIM_STEP;

static void nearCallback (void *data, dGeomID o1, dGeomID o2)
{
	int i,j,n;
	bool ray_flag;
	dBodyID b1 = dGeomGetBody(o1);
	dBodyID b2 = dGeomGetBody(o2);
	if (b1 && b2 && dAreConnectedExcluding(b1,b2,dJointTypeContact)) return;

	dContact contact[COLLIDE_MAX];
	
	n = dCollide(o1,o2,COLLIDE_MAX,&contact[0].geom,sizeof(dContact));

	if (n > 0) {	
		for (i=0; i<n; i++) {
			ray_flag=false;
			for (j=0; j<SUB_SENSOR_MAX; j++){
				if((o1==EPUCK.ir_sensor[j].ray || o2==EPUCK.ir_sensor[j].ray) 
					&& (o1!=EPUCK.base.geom && o2!=EPUCK.base.geom)){
					ray_flag=true;
					EPUCK.ir_sensor[j].collide_flag=true;
					EPUCK.ir_sensor[j].collide_pos[EPUCK.ir_sensor[j].collide_cnt][0]=contact[i].geom.pos[0];
					EPUCK.ir_sensor[j].collide_pos[EPUCK.ir_sensor[j].collide_cnt][1]=contact[i].geom.pos[1];
					EPUCK.ir_sensor[j].collide_pos[EPUCK.ir_sensor[j].collide_cnt][2]=contact[i].geom.pos[2];
					EPUCK.ir_sensor[j].collide_cnt++;
				}
			}

			for (j=0;j<WALL_MAX;j++){
				if((o1==ENVIRONMENT[j].geom || o2==ENVIRONMENT[j].geom) && (o1==EPUCK.base.geom || o2==EPUCK.base.geom)){
					EPUCK.collide_flag=true;
				}
			}
            if (ray_flag==false){
				contact[i].surface.mode = dContactSlip1 | dContactSlip2 |
									dContactSoftERP | dContactSoftCFM | dContactApprox1;
				contact[i].surface.mu       = NormalRandom(0.65, 0.65*DRIVE_NOISE_RANGE);//dInfinity; 
				if (contact[i].surface.mu<=0) contact[i].surface.mu=0.1;
				contact[i].surface.slip1    = 0.05f;//0.05
				contact[i].surface.slip2    = 0.05f;//0.05
				contact[i].surface.soft_erp = 0.6f;
				contact[i].surface.soft_cfm = (dReal)1e-10;
				dJointID c = dJointCreateContact(world,contactgroup,&contact[i]);
				dJointAttach(c,b1,b2);
			}
		}
	}
}

static void simLoop(int pause)
{
	
	SensorSet();
	dSpaceCollide (space,0,&nearCallback);/////////////////////////////
	dWorldStep (world,0.01f);
	dJointGroupEmpty (contactgroup);

	EpuckControll();
	
	if (DRAW){
		DrawRobot();
		DrawWall();
	}
}

static void start()
{
  float xyz[3] = {  1.0f, -4.0f, 5.0f};
  float hpr[3] = { 60.0f, -30.0f, 0.0f};

  dsSetViewpoint(xyz,hpr);
  dsSetSphereQuality(3);

  printf ("Press:\t's' to start the simulation.\n"
			"\t'8' to move forward.\n"
			"\t'2' to move backward.\n"
			"\t'4' to turn the left.\n"
			"\t'6' to turn the right.\n"
			"\t'5' to stop.\n"
			"\t'l' to move along the left wall.\n"
			"\t'r' to reset the simulation.\n");
}

static void setDrawStuff() 
{
  fn.version = DS_VERSION;
  fn.start   = &start;
  fn.step    = &simLoop;
  fn.command = &command;
  fn.path_to_textures = "textures";
}

static void command(int cmd)
{
  switch (cmd) {
	case '8':
		EPUCK.leftwheelspeed=0.5;
		EPUCK.rightwheelspeed=0.5;
		break;
	case '2':
		EPUCK.leftwheelspeed=-0.2;
		EPUCK.rightwheelspeed=-0.2;
		break;
	case '4':
		EPUCK.leftwheelspeed=-0.2;
		EPUCK.rightwheelspeed=0.2;
		break;
	case '5':
		EPUCK.leftwheelspeed=0;
		EPUCK.rightwheelspeed=0;
		break;
	case '6':
		EPUCK.leftwheelspeed=0.2;
		EPUCK.rightwheelspeed=-0.2;
		break;
	case 's':
		AGENT.end_flag =false;
		break;
	case 'l':
		AGENT.left_wall_flag=!AGENT.left_wall_flag;
		EPUCK.leftwheelspeed=0;
		EPUCK.rightwheelspeed=0;
		break;
	case 'r':
		SIM_STEP=1;
		EvaluationReset();
		AGENT.end_flag =true;
		EpuckResetPosition();
		printf("\nReset!\n\n");
		 printf ("Press:\t's' to start the simulation.\n"
			"\t'8' to move forward.\n"
			"\t'2' to move backward.\n"
			"\t'4' to turn the left.\n"
			"\t'6' to turn the right.\n"
			"\t'5' to stop.\n"
			"\t'l' to move along the left wall.\n"
			"\t'r' to reset the simulation.\n");
		break;
  }
}

int main(int argc, char *argv[])
{

	setDrawStuff(); 
	dInitODE();
	world        = dWorldCreate();
	space        = dHashSpaceCreate(0);
	contactgroup = dJointGroupCreate(0);
	ground       = dCreatePlane(space,0,0,1,0);

	dWorldSetGravity(world, 0, 0, -98.0);

	srand(seed);

	MakeRobot();
	MakeWall();

	SIM_STEP=1;
	EvaluationReset();
	AGENT.end_flag=true;
	EpuckResetPosition();

	if (DRAW==true)
		dsSimulationLoop(argc,argv,800,600,&fn);
	else{
		while(1){
			simLoop(0);
		}
	}
	dSpaceDestroy(space);
	dWorldDestroy(world);
	dCloseODE(); 
	return 0;
}
