void MakeWall();
void DrawWall();
void WallPosition();