#include <stdio.h>
#include <ode/ode.h>
#include "main.h"
#include "EpuckModel.h"
#include "EpuckController.h"
#include "Environment.h"
#include "MathFunction.h"
#include "Evaluation.h"

void EpuckControll(void){

	int ir_sensor_value[SENSOR_MAX];
	int i;

	if (AGENT.end_flag==false){
		/****************�Z���T****************/
		GetIrSensorValue(ir_sensor_value);
		/***************************�ǏՓ˔���*************************/    
		for (i=0;i<SENSOR_MAX;i++){
			if(ir_sensor_value[i]>=SENSOR_VALUE_MAX){
				EPUCK.collide_flag=true;
				break;
			}
		}
		/***************************�����܂�*************************/

		/****************�����܂�****************/

		if (SIM_STEP%TRANS_PERIOD==0){//PC�C���@�Ԃ̒ʐM����

			/****************�ړ�****************/
			if (AGENT.left_wall_flag==true)
				MoterControlLeftWall(ir_sensor_value,&(EPUCK.leftwheelspeed),&(EPUCK.rightwheelspeed));//���ǉ������[�^����

			ControlWheel((dReal)(2.0*PI*WHEEL_SPEED*EPUCK.leftwheelspeed),
						(dReal)(2.0*PI*WHEEL_SPEED*EPUCK.rightwheelspeed));
			/****************�����܂�****************/

			/***************************�]��1*************************/    
			if (EPUCK.leftwheelspeed<0 && EPUCK.rightwheelspeed<0){
					AGENT.output_sum=AGENT.output_sum
											-(EPUCK.leftwheelspeed*EPUCK.rightwheelspeed)
											*log((double)ir_sensor_value[5]+1.0)/log(SENSOR_VALUE_MAX);
			}
			else {
				AGENT.output_sum=AGENT.output_sum
											+(EPUCK.leftwheelspeed*EPUCK.rightwheelspeed)
											*log((double)ir_sensor_value[5]+1.0)/log(SENSOR_VALUE_MAX);
			}
			/***************************�����܂�*************************/    
		}

		/***************************�]��2*************************/    
		EPUCK.pos = dBodyGetPosition(EPUCK.base.body);
		EvaluationSubgoal(EPUCK.pos[0],PASSAGE_WIDTH*5-EPUCK.pos[1]);
		/***************************�����܂�*************************/    

		/***************************��ԕ\��*************************/    
		if(DRAW==true){
			printf("TIME:%5.2f[s], x:%4.3f[m], y:%4.3f[m], l_motor:%4.3f[rad/s], r_motor:%4.3f[rad/s], SG:%4d, OUT:%4.2f, FIT:%4d\n",
				    0.01*(float)SIM_STEP, 0.1*EPUCK.pos[0],  0.1*EPUCK.pos[1], 
					2.0*PI*WHEEL_SPEED*EPUCK.leftwheelspeed,
					2.0*PI*WHEEL_SPEED*EPUCK.rightwheelspeed,
					AGENT.E_value, AGENT.output_sum,
					AGENT.E_value+(int)AGENT.output_sum);
		}
		/***************************�����܂�*************************/    

		if (SIM_STEP>=STEP_MAX){
			AGENT.end_flag=true;
			ControlWheel(0,0);
			printf("Time over! Simulation finished.\nPress: r to reset simulation.\n");
		}
		else if(EPUCK.collide_flag==true){
			AGENT.end_flag=true;
			ControlWheel(0,0);
			printf("Hit a wall! Simulation finished.\nPress: r to reset simulation.\n");
		}
		else
			SIM_STEP++;

	}
	return;

}

void MoterControlLeftWall(int sensor_value[], dReal* leftwheel, dReal* rightwheel)
{

	int follow_weightleft[8] = {-10,-10,-5,0,0,5,10,10};
	int follow_weightright[8] = {10,10,5,0,0,-5,-10,-10};

	int i,gostraight;

	int value[8];

	gostraight=0;

	for (i=0; i<8; i++) {
		value[i]=sensor_value[i];
	}

	gostraight=1;
	for (i=0; i<8; i++) {
		if (value[i]>50) {
			gostraight=0;
			break;
		}
	}

	if (gostraight==0){
		*leftwheel=350;
		*rightwheel=350;
		follow_weightleft[0]=10;
		follow_weightleft[7]=10;
		follow_weightright[0]=-10;
		follow_weightright[7]=-10;
		if (value[5]>300) {
			value[4]-=100;
			value[5]-=200;
			value[6]-=200;
		}
		for (i=0; i<8; i++) {
			*leftwheel+=follow_weightleft[i]*(value[i]>>4);
			*rightwheel+=follow_weightright[i]*(value[i]>>4);
		}
	}
	else{
		*leftwheel=300;
		*rightwheel=700;
	}

	if (*leftwheel>800) *leftwheel=800;
	if (*leftwheel<-800) *leftwheel=-800;
	if (*rightwheel>800) *rightwheel=800;
	if (*rightwheel<-800) *rightwheel=-800;

	*leftwheel=*leftwheel/1000;
	*rightwheel=*rightwheel/1000;

	return;
}

void EpuckResetPosition(void){
	
	int i;
	dReal w1x = (dReal)(BASE_r-0.095);
	dReal w1z = - 0.005f ;
	dMatrix3 R;
	dReal rnd_angle;

	rnd_angle= 0.0;
	//rnd_angle= (dReal)(M_PI/4.0*(ran_f()-0.5));
	
    dBodySetPosition(EPUCK.base2.body,(dReal)START_X2,(dReal)START_Y2,(dReal)START_Z2+BASE_l/2+BASE_l1+BASE_l2/2);
    dBodySetPosition(EPUCK.base1.body,(dReal)START_X1,(dReal)START_Y1,(dReal)START_Z1+BASE_l/2+BASE_l1/2);
	dBodySetPosition(EPUCK.base.body,(dReal)START_X,(dReal)START_Y,(dReal)START_Z);
	dBodySetPosition(EPUCK.wheel[0].body, (dReal)START_X-w1x*cos(rnd_angle), 
										  (dReal)START_Y-w1x*sin(rnd_angle), w1z+(dReal)START_Z);  
	dBodySetPosition(EPUCK.wheel[1].body, (dReal)START_X+w1x*cos(rnd_angle), 
										  (dReal)START_Y+w1x*sin(rnd_angle), w1z+(dReal)START_Z); 
	dRFromAxisAndAngle(R,0,0,1,rnd_angle);
	dBodySetRotation(EPUCK.base.body,R);

	ControlWheel(0,0);

	for (i=0;i<SUB_SENSOR_MAX;i++){
			EPUCK.ir_sensor[i].value=0;
	}
	
	EPUCK.collide_flag=false;

	return;
}
