/*
 * An optimization benchmark problem for the energy plant operational planning problem
 * (header file)
 * Written by Takashi Okamoto (takashi@faculty.chiba-u.jp)
 * Last update on Dec. 25th, 2016
 *
 * Variables
 *  x : continuous decision variables
 *  y : discrete decision variables
 *  N_x : number of continuous decision variables
 *  N_y : number of discrete decision variables
 *  P : number of objective funcitons
 *  M : number of inequality conditions
 *  Q : number of equality conditions
 *  eps : tolerance for constraint violations
 *
 * Funcitons
 *  "evaluation" sets objective function values to f,
 *  inequality condition function values to g, and
 *  equality condition function values to h.
 *  "checkFeasibility" returns feasibility of decision variables
 */
#include <cmath>
#include <string>
#include <fstream>

class P1 {
public:
	//Constructor
	P1();

	//Public methods
	void evaluation(double *, double *, double *, double *, double *);
	bool checkFeasibility(double *, double *);

	//Constants
	int N_x, N_y, P, M, Q; //common variables
	double eps; //common variables
	int I, N_tr, N_sr, N, *L_tr, *L_sr, L_gt, L_bl;
	double a_gte, a_gts, a_bl, *a_tr, *a_sr, *b_sr, *c_sr, *Q_tr_min, *Q_tr_max, *Q_sr_min, *Q_sr_max, E_gt_min, E_gt_max, S_bl_min, S_bl_max, Q_ts_min, Q_ts_max1, Q_ts_max2, Q_ts_init, Q_loss, *C_E, *C_F, *E_L, *E_DR, *E_PV, *Q_L, *S_L, B_bs_min, B_bs_max, B_bs_init, c_eff_plus, c_eff_minus, r_c, C_cd, T_E, T_F, b_cd, r_cd;

	//Energy purchase cost and CO2 emission
	double f_p, f_cd;

	//Destructor
	~P1();

private:
	//Private methods
	void initialization();
	void readArray(double **, const int, const std::string &);
	void readArray(int **, const int, const std::string &);
	double E_B(const int);
	double compute_Q_ts(const int, const double);
	double compute_B_bs(const int, const double);
	double f_sr_j(const int, const int);

	//Private members
	double **x_tr, **x_sr, *x_gt, *x_bl, **y_tr, **y_sr, *y_gt, *y_bl, *x_bs, *Q_ts, *B_bs;
};
