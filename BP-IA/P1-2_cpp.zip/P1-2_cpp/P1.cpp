/*
 * An optimization benchmark problem for the energy plant operational planning problem
 * (main file)
 * Written by Takashi Okamoto (takashi@faculty.chiba-u.jp)
 * Last update on Dec. 25th, 2016
 */
#include "P1.h"
#include <iostream>
using namespace std;

/* Constructor */
P1::P1()
{
	//Set constants
	initialization();

	/* Set common variables */
	N_x = I * (N_tr + N_sr + 3); //x_tr, x_sr, x_gt, x_bl, x_bs
	N_y = I * (N_tr + N_sr + 2); //y_tr, y_sr, y_gt, y_bl
	P = 1;
	M = I * (2 + 2 + 1 + 2 * N_tr + 2 * N_sr + 2 + 2); //Eqs. (2) and (3), (4), (5), (8), (9), (10), (11)
	Q = I + (I - L_tr[0]) + (I - L_sr[0]) + (I - L_sr[1]) + (I - L_gt) + (I - L_bl); //Eqs. (7), (12), (13), (14), (15)

	//Count steps at which the constraint (6) can be active
	for (int i = 0; i < I; i++) {
		if (E_DR[i] > 1.0E-10) {
			M++;
		}
	}

	//Memory allocation
	x_tr = new double *[N_tr];
	y_tr = new double *[N_tr];
	for (int n = 0; n < N_tr; n++) {
		x_tr[n] = new double [I];
		y_tr[n] = new double [I];
	}
	x_sr = new double *[N_sr];
	y_sr = new double *[N_sr];
	for (int n = 0; n < N_sr; n++) {
		x_sr[n] = new double [I];
		y_sr[n] = new double [I];
	}
	x_gt = new double [I];
	y_gt = new double [I];
	x_bl = new double [I];
	y_bl = new double [I];
	x_bs = new double [I];
	Q_ts = new double [I];
	B_bs = new double [I];
}

/* Destructor */
P1::~P1()
{
	//Release memory
	for (int n = 0; n < N_tr; n++) {
		delete [] x_tr[n];
		delete [] y_tr[n];
	}
	delete [] x_tr;
	delete [] y_tr;
	for (int n = 0; n < N_sr; n++) {
		delete [] x_sr[n];
		delete [] y_sr[n];
	}
	delete [] x_sr;
	delete [] y_sr;
	delete [] x_gt;
	delete [] y_gt;
	delete [] x_bl;
	delete [] y_bl;
	delete [] x_bs;
	delete [] Q_ts;
	delete [] B_bs;
	delete [] a_tr;
	delete [] a_sr;
	delete [] b_sr;
	delete [] c_sr;
	delete [] Q_tr_min;
	delete [] Q_tr_max;
	delete [] Q_sr_min;
	delete [] Q_sr_max;
	delete [] L_tr;
	delete [] L_sr;
	delete [] C_E;
	delete [] C_F;
	delete [] E_L;
	delete [] E_DR;
	delete [] E_PV;
	delete [] Q_L;
	delete [] S_L;
}

/* Evaluation function */
void P1::evaluation(double *x, double *y, double *f, double *g, double *h)
{
	//Substitution of x and y
	int cnt = 0;
	for (int n = 0; n < N_tr; n++) {
		for (int i = 0; i < I; i++) {
			x_tr[n][i] = x[cnt];
			y_tr[n][i] = y[cnt];
			cnt++;
		}
	}
	for (int n = 0; n < N_sr; n++) {
		for (int i = 0; i < I; i++) {
			x_sr[n][i] = x[cnt];
			y_sr[n][i] = y[cnt];
			cnt++;
		}
	}
	for (int i = 0; i < I; i++) {
		x_gt[i] = x[cnt];
		y_gt[i] = y[cnt];
		cnt++;
	}
	for (int i = 0; i < I; i++) {
		x_bl[i] = x[cnt];
		y_bl[i] = y[cnt];
		cnt++;
	}
	for (int i = 0; i < I; i++) {
		x_bs[i] = x[cnt];
		cnt++;
	}

	//Compute Q_ts
	Q_ts[0] = compute_Q_ts(0, Q_ts_init);
	for (int i = 1; i < I; i++) {
		Q_ts[i] = compute_Q_ts(i, Q_ts[i - 1]);
	}

	//Compute B_bs
	B_bs[0] = compute_B_bs(0, B_bs_init);
	for (int i = 1; i < I; i++) {
		B_bs[i] = compute_B_bs(i, B_bs[i - 1]);
	}

	//Compute objective function - Eq. (1)
	f[0] = 0.0;
	f_p = 0.0;
	f_cd = 0.0;
	for (int i = 0; i < I; i++) {
		f_p += C_E[i] * E_B(i) + C_F[i] * (x_gt[i] + x_bl[i]);
		f_cd += T_E * E_B(i) + T_F * (x_gt[i] + x_bl[i]);
	}
	f[0] = f_p + C_cd * (f_cd - r_cd * b_cd);

	/* Compute constraint conditions */
	//Eqs. (2) and (3)
	int id_g = 0;
	for (int i = 0; i < I; i++) {
		g[id_g] = Q_ts_min - Q_ts[i];
		id_g++;
	}
	for (int i = 0; i < I; i++) {
		if (i < I - 1) {
			g[id_g] = Q_ts[i] - Q_ts_max1;
		} else {
			g[id_g] = Q_ts[i] - Q_ts_max2;
		}
		id_g++;
	}

	//Eq. (4)
	for (int i = 0; i < I; i++) {
		g[id_g] = B_bs_min - B_bs[i];
		id_g++;
	}
	for (int i = 0; i < I; i++) {
		g[id_g] = B_bs[i] - B_bs_max;
		id_g++;
	}

	//Eq. (5)
	for (int i = 0; i < I; i++) {
		g[id_g] = -E_B(i);
		id_g++;
	}

	//Eq. (6)
	for (int i = 0; i < I; i++) {
		if (E_DR[i] > 1.0E-10) {
			g[id_g] = E_B(i) - E_L[i] + E_DR[i];
			id_g++;
		}
	}

	//Eq. (7)
	int id_h = 0;
	for (int i = 0; i < I; i++) {
		h[id_h] = a_gts * x_gt[i] + a_bl * x_bl[i];
		for (int j = 0; j < N_sr; j++) {
			h[id_h] -= f_sr_j(j, i);
		}
		h[id_h] -= S_L[i];
		id_h++;
	}

	//Eq. (8)
	for (int j = 0; j < N_tr; j++) {
		for (int i = 0; i < I; i++) {
			g[id_g] = Q_tr_min[j] * y_tr[j][i] - x_tr[j][i];
			id_g++;
		}
	}
	for (int j = 0; j < N_tr; j++) {
		for (int i = 0; i < I; i++) {
			g[id_g] = x_tr[j][i] - Q_tr_max[j] * y_tr[j][i];
			id_g++;
		}
	}

	//Eq. (9)
	for (int j = 0; j < N_sr; j++) {
		for (int i = 0; i < I; i++) {
			g[id_g] = Q_sr_min[j] * y_sr[j][i] - x_sr[j][i];
			id_g++;
		}
	}
	for (int j = 0; j < N_sr; j++) {
		for (int i = 0; i < I; i++) {
			g[id_g] = x_sr[j][i] - Q_sr_max[j] * y_sr[j][i];
			id_g++;
		}
	}

	//Eq. (10)
	for (int i = 0; i < I; i++) {
		g[id_g] = E_gt_min * y_gt[i] - a_gte * x_gt[i];
		id_g++;
	}
	for (int i = 0; i < I; i++) {
		g[id_g] = a_gte * x_gt[i] - E_gt_max * y_gt[i];
		id_g++;
	}

	//Eq. (11)
	for (int i = 0; i < I; i++) {
		g[id_g] = S_bl_min * y_bl[i] - a_bl * x_bl[i];
		id_g++;
	}
	for (int i = 0; i < I; i++) {
		g[id_g] = a_bl * x_bl[i] - S_bl_max * y_bl[i];
		id_g++;
	}

	//Eq. (12)
	for (int j = 0; j < N_tr; j++) {
		for (int i = 0; i < I - 1; i++) {
			for (int tau = i + 2; tau < i + L_tr[j] + 1; tau++) {
				if (tau < I) {
					h[id_h] = (y_tr[j][i + 1] - y_tr[j][i]) * (y_tr[j][i + 1] - y_tr[j][tau]);
					id_h++;
				}
			}
		}
	}

	//Eq. (13)
	for (int j = 0; j < N_sr; j++) {
		for (int i = 0; i < I - 1; i++) {
			for (int tau = i + 2; tau < i + L_sr[j] + 1; tau++) {
				if (tau < I) {
					h[id_h] = (y_sr[j][i + 1] - y_sr[j][i]) * (y_sr[j][i + 1] - y_sr[j][tau]);
					id_h++;
				}
			}
		}
	}

	//Eq. (14)
	for (int i = 0; i < I - 1; i++) {
		for (int tau = i + 2; tau < i + L_gt + 1; tau++) {
			if (tau < I) {
				h[id_h] = (y_gt[i + 1] - y_gt[i]) * (y_gt[i + 1] - y_gt[tau]);
				id_h++;
			}
		}
	}

	//Eq. (15)
	for (int i = 0; i < I - 1; i++) {
		for (int tau = i + 2; tau < i + L_gt + 1; tau++) {
			if (tau < I) {
				h[id_h] = (y_bl[i + 1] - y_bl[i]) * (y_bl[i + 1] - y_bl[tau]);
				id_h++;
			}
		}
	}
}

/* Check feasibility */
bool P1::checkFeasibility(double *x, double *y)
{
	/* Check feasibility of y */
	bool feasibility = true;
	for (int n = 0; n < N_y; n++) {
		if (y[n] < 0 || y[n] > 2) {
			feasibility = false;
		}
	}

	/* Compute f, g, and h */
	double *f, *g, *h;
	f = new double[P];
	g = new double[M];
	h = new double[Q];
	evaluation(x, y, f, g, h);

	/* Check inequality conditions */
	for (int m = 0; m < M; m++) {
		if (g[m] > eps) {
			feasibility = false;
		}
	}

	/* Check equality conditions */
	for (int q = 0; q < Q; q++) {
		if (fabs(h[q]) > eps){
			feasibility = false;
		}
	}

	/* Memory release */
	delete [] f;
	delete [] g;
	delete [] h;

	return feasibility;
}

/* Private methods */
void P1::initialization()
{
	//Read constants
	std::ifstream ifs;
	ifs.open("P1_constants.conf");
	std::string tmp;
	ifs >> tmp >> I >> tmp >> N_tr >> tmp >> N_sr >> tmp >> a_gte >> tmp >> a_gts >> tmp >> a_bl >> tmp >> E_gt_min >> tmp >> E_gt_max >> tmp >> S_bl_min >> tmp >> S_bl_max >> tmp >> Q_ts_min >> tmp >> Q_ts_max1 >> tmp >> Q_ts_max2 >> tmp >> Q_ts_init >> tmp >> Q_loss >> tmp >> L_gt >> tmp >> L_bl >> tmp >> B_bs_min >> tmp >> B_bs_max >> tmp >> B_bs_init >> tmp >> c_eff_plus >> tmp >> c_eff_minus >> tmp >> r_c >> tmp >> T_E >> tmp >> T_F >> tmp >> b_cd >> tmp >> r_cd >> tmp >> C_cd;
	ifs.close();

	//Read tolerance for constraint violations
	ifs.open("P1_tolerance.conf");
	ifs >> eps;
	ifs.close();

	//Read array constants
	readArray(&a_tr, N_tr, "P1_a_tr.conf");
	readArray(&a_sr, N_sr, "P1_a_sr.conf");
	readArray(&b_sr, N_sr, "P1_b_sr.conf");
	readArray(&c_sr, N_sr, "P1_c_sr.conf");
	readArray(&Q_tr_min, N_tr, "P1_Q_tr_min.conf");
	readArray(&Q_tr_max, N_tr, "P1_Q_tr_max.conf");
	readArray(&Q_sr_min, N_sr, "P1_Q_sr_min.conf");
	readArray(&Q_sr_max, N_sr, "P1_Q_sr_max.conf");
	readArray(&L_tr, N_tr, "P1_L_tr.conf");
	readArray(&L_sr, N_sr, "P1_L_sr.conf");
	readArray(&C_E, I, "P1_C_E.conf");
	readArray(&C_F, I, "P1_C_F.conf");
	readArray(&E_L, I, "P1_E_L.conf");
	readArray(&E_DR, I, "P1_E_DR.conf");
	readArray(&E_PV, I, "P1_E_PV.conf");
	readArray(&Q_L, I, "P1_Q_L.conf");
	readArray(&S_L, I, "P1_S_L.conf");
}

/*  Read double array */
void P1::readArray(double **A, const int N, const std::string &filename)
{
	std::ifstream ifs(filename.c_str());
	*A = new double [N];
	for (int i = 0; i < N; i++) {
		ifs >> (*A)[i];
	}
	ifs.close();
}

/* Read integer array */
void P1::readArray(int **A, const int N, const std::string &filename)
{
	std::ifstream ifs(filename.c_str());
	*A = new int [N];
	for (int i = 0; i < N; i++) {
		ifs >> (*A)[i];
	}
	ifs.close();
}

/* Eq. (20) */
double P1::E_B(const int i)
{
	double f_tr = 0.0;
	for (int j = 0; j < N_tr; j++) {
		f_tr += a_tr[j] * x_tr[j][i];
	}
	return f_tr + E_L[i] - E_PV[i] - x_bs[i] - a_gte * x_gt[i];
}

/* Eq. (18) */
double P1::compute_Q_ts(const int i, const double Q_ts_i_minus_1)
{
	double Q_ts_i = 0.0;
	for (int j = 0; j < N_tr; j++) {
		Q_ts_i -= x_tr[j][i];
	}
	for (int j = 0; j < N_sr; j++) {
		Q_ts_i -= x_sr[j][i];
	}
	Q_ts_i += Q_ts_i_minus_1 + Q_L[i] + Q_loss;
	return Q_ts_i;
}

/* Eq. (19) */
double P1::compute_B_bs(const int i, const double B_bs_i_minus_1)
{
	double f_eff;
	if (x_bs[i] < 0) {
		f_eff = c_eff_minus / r_c * x_bs[i];
	} else {
		f_eff = c_eff_plus / r_c * x_bs[i];
	}
	return B_bs_i_minus_1 - f_eff;
}

/* Eq. (27) */
double P1::f_sr_j(const int j, const int i)
{
	return x_sr[j][i] / (-a_sr[j] * x_sr[j][i] * x_sr[j][i] + b_sr[j] * x_sr[j][i] + c_sr[j]);
}
