## C++ source codes of the benchmark problem for the automatic picking system operational planning problem [1-4] ##

These codes are edited by the investigating R&D committee on new development of computational intelligence techniques and their applications to industrial systems, the institute of electrical engineers of Japan. These codes are implemented based on the latest formulation of automatic picking system operational planning problem in [4].

1. Archived files

1.1 Source files
 -- P3.cpp                      : P3 (the automatic picking system operational planning problem) class main file
 -- P3.h                        : P3 class header file
 -- P3_evaluation.cpp           : sample source code including main function to test P3 class

1.2 Sample input files and documents
 -- P3_data_sample_xx.csv       : problem setting file (two types of problem are prepared (xx = 00 or 01)) 
 -- P3_solution_y_sample_xx.txt : sample feasible solution file (prepared for each problem above)
 -- P3_constants.conf           : configuration file which includes the problem constants
 -- P3_tolerance.conf           : configuration file which includes the tolerance value for constraint violations
 -- readme.txt                  : this file

The detail of input files are described in Sect. 3.

2. Implementing and running the sample code

2.1 Preparetion

P3 class requires two fixed-name files "P3_constants.conf" and "P3_tolerance.conf" in the current directory. 
In addition, the sample code requires two fixed-name files "P3_data.csv" and "P3_soution_y," which can be prepared by renaming of "P3_data_sample_xx.csv" and "P3_solution_y_sample_xx.txt" described in Sect. 1.2, respectively.

2.2 Visual C++
    $ cl P3.cpp P3_evaluation.cpp /FeP3.exe /EHsc
    $ P3.exe

2.3 gcc
    $ g++ P3.cpp P3_evaluation.cpp -o P3.out
    $ ./P3.out

# "$" means command prompt.

3. Input Files

3.1 Constants file
Constants file includes following items:
 -- N_L   : number of lanes,
 -- N_k   : number of kinds of products,
 -- N_S   : number of stores,
 -- N_P   : number of products,
 -- alpha : speed of conveyer,
 -- beta  : minimum space on conveyer between products of different requests.

NOTE : All constants must be natural number, and N_k, N_S, N_P must consistent with the problem setting specified in "P3_data.csv."

  [example] P3_constants.conf
    N_L         100
    N_K         90
    N_S         50
    N_P         9000
    alpha       4
    beta        8

3.2 Tolerance file
Tolerance file includes tolerance value for constraint violations. 
The tolerance value is applied to all constraint conditions individually. 
P3 class judges a solution as feasible only if all constraint violations are within the specified tolerance value.

  [example] P3_tolerance.conf
    1.0E-10

3.3 problem setting file
Problem setting file should be written in CSV format, which begins with the label row including items "N", "S", "R", and "K" in the order. 
The picking planning problem to be optimized should be specified from the second line of the problem setting file in the following manner:
 -- S : index of the shop (The destination of the picked-up products),
 -- R : index of the requirement of shop S,  
 -- K : index of the product kind,
 -- N : required amount of product kind K for the requirement R of shop S.

  [example] P3_data_sample_00.csv (an extract)
    N, S, R, K 
    1, 1, 1, 12
    1, 1, 1, 18
    1, 1, 1, 24
    3, 1, 1, 30
    1, 1, 1, 50
    1, 1, 1, 51
    1, 1, 1, 57
    1, 1, 1, 58
    1, 1, 1, 62
    1, 1, 1, 64
    2, 1, 1, 66
    1, 1, 1, 67
    1, 1, 1, 72
    1, 1, 1, 80
    1, 1, 1, 87
    2, 1, 2, 10
    1, 1, 2, 16
    1, 1, 2, 22
   (The rest is omitted.)

In above example case, the requirent 1 of the shop 1 includes follwing items:
  product kind 12 x 1, product kind 18 x 1, product kind 24 x 1,  product kind 30 x 3, 
  product kind 50 x 1, product kind 51 x 1, product kind 57 x 1,  product kind 58 x 1, 
  product kind 62 x 1, product kind 64 x 1, product kind 66 x 2,  product kind 67 x 1, 
  product kind 72 x 1, product kind 80 x 1, and product kind 87 x 1. 

3.4 Solution file
Solution file includes the values of discrete decision variables for P3 as a vector. 
P3 class rearranges the vector to decision variables in the order of y_S, y_R, y_K, y_P, y_T.
Two or three dimensional variables y_S, y_R, y_K, and y_P are arranged in one dimensional array for convenience in implementation.

  [exsample]
    y_S = (y[0], ... , y[N_S - 1],  y[N_S], ... , y[2 * N_S - 1], ... , y[N_S * N_S - N_S], ... , y[N_S * N_S - 1])
           ~~~~~~~~~~~~~~~~~~~~~~   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
           s=0, u=0, ... ,N_S - 1      s=1, u=0, ... ,N_S - 1                s=N_S-1, u=0, ... ,N_S - 1  

  NOTE : The size and the order of independent variables in the vector must be consistent with the problem setting.

4. Output files

The sample code generates the detail information of the input solution into following files:
 -- P3_result_x.txt : real independent variables (P3 has no real independent variables, however),
 -- P3_result_y.txt : matrix-formed integer independent variables,
 -- P3_result_f.txt : objective function values,
 -- P3_result_g.txt : violation amount for each inequality condition, 
 -- P3_result_h.txt : violation amount for each equality condition,
 -- P3_result_c.txt : table-formed picking schedule for the input solution.


5. Public members of P3 class

5.1 Public methods

5.1.1 void P3::evaluation(double *x, double *y, double *f, double *g, double *h)
This function sets objective function values f(x, y) to f, inequality condition function values g(x, y) to g, and equality condition function values h(x, y) to h.
 
  [arguments]
   -- double *x : [INPUT]  continuous decision variables        (x[ 0 ], x[ 1 ], ... , x[ N_x - 1 ])
   -- double *y : [INPUT]  discrete decision variables          (y[ 0 ], y[ 1 ], ... , y[ N_y - 1 ])
   -- double *f : [OUTPUT] objective funciton function values   (f[ 0 ], f[ 1 ], ... , f[ P   - 1 ])
   -- double *g : [OUTPUT] inequality condition function values (g[ 0 ], g[ 1 ], ... , g[ M   - 1 ])
   -- double *h : [OUTPUT] equality condition function values   (h[ 0 ], h[ 1 ], ... , h[ Q   - 1 ])

  [return] 
    Nothing

5.1.2 bool P3::checkFeasibility(double *x, double *y)
This function returns feasibility of decision variables.

  [arguments]
   -- *x : [INPUT] continuous decision variables (x[ 0 ], x[ 1 ], ... , x[ N_x - 1 ])
   -- *y : [INPUT] discrete decision variables   (y[ 0 ], y[ 1 ], ... , y[ N_y - 1 ])

  [return] 
    true  : feasible
    false : infeasible

5.1.3 int P3::C_P(const int p, const double *y_P, const double *y_T) const
This function returns p-th conveyer's position.
 
  [arguments]
   -- p    : [INPUT] the product number              ( p = 0, 1, ..., N_P - 1 )
   -- *y_P : [INPUT] discrete decision variables y_P ( y_P[0], y_P[1], ..., y_P[ N_P * N_L - 1 ] )
   -- *y_T : [INPUT] discrete decision variables y_T ( y_T[0], y_T[1], ..., y_T[ N_P - 1 ] )

  [return] 
    p-th conveyer's position ( C_P(p) = 0, 1, ... ) 

  NOTE : y_P[] and y_T[] must be feasible to calculate C_P correctly. 

5.1.4 int  P3::S_U(const int u, const double *y_S) const
This function returns the store number s which is done in order u.
 
  [arguments]
   -- u    : [INPUT] the order to do in a store      ( u = 0, 1, ..., N_S - 1 )
   -- *y_S : [INPUT] discrete decision variables y_S ( y_S[0], y_S[1], ..., y_S[ N_S * N_S - 1 ] )

  [return] 
    the store number s which is done in order u ( 0 <= s <= N_S - 1 )

  NOTE : y_S[]  must be feasible to calculate S_U correctly. 

5.1.5 int  P3::R_V(const int s, const int v, const double *y_R) const
This function returns the request number r in store s which is done in order v.

  [arguments]
   -- s    : [INPUT] the store number                               ( s = 0, 1, ..., N_S - 1 )
   -- v    : [INPUT] the order to do in a request in store number s ( u = 0, 1, ..., N_S - 1 )    
   -- *y_R : [INPUT] discrete decision variables y_R                ( y_R[0], y_R[1], ..., y_R[ Y_K_BASE - Y_R_BASE - 1 ] )

  [return] 
   the request number r in store s which is done ( 0 <= r <= N_R[ s ] - 1 )

  NOTE : y_R[] must be feasible to calculate R_V correctly.

5.2 public properties
 -- int     P3.N_x       : number of continuous decision variables
 -- int     P3.N_y       : number of discrete decision variables
 -- int     P3.P         : number of objective funcitons
 -- int     P3.M         : number of inequality conditions
 -- int     P3.Q         : number of equality conditions
 -- int     P3.N_L       : number of lanes
 -- int     P3.N_K       : number of kinds of products
 -- int     P3.N_S       : number of stores
 -- int     P3.N_P       : number of products
 -- int     P3.alpha     : speed of conveyer
 -- int     P3.beta      : minimum space on conveyer between products of different requests
 -- int *   P3.N_R       : number of requests in store S, N_R[s] 
                          ( s = 0, 1, ..., N_S - 1 ) 
 -- int *   P3.S_P       : the store number s of product number p 
                          ( s = S_P[ p ], p = 0, 1, ..., N_P - 1, 0 <= s <= N_S - 1 )  	
 -- int *   P3.R_P       : the request number r of product number p
                          ( r = R_P[ p ], p = 0, 1, ..., N_P - 1, 0 <= r <= N_R[ S_P[ p ] ] - 1 )
 -- int *   P3.K_P       : the kind number k of product number p 
                          ( k = K_P[ p ], p = 0, 1, ..., N_P - 1, 0 <= k <= N_K - 1 )
 -- int *   P3.N_G_S     : number of products for store s, N_G_S[ s ] 
                          ( s = 0, 1, ..., N_S - 1 )
 -- int **  P3.N_G_R     : number of products for store s and request r, N_G_R[ s ][ r ]  
                          ( s = 0, 1, ..., N_S - 1, r = 0, 1, ..., N_R[ s ] - 1 )
 -- int **  P3.G_S       : product number for store s, G_S[s][id]
                          ( s = 0, 1, ..., N_S - 1, id = 0, 1, ..., N_G_S[ s ] - 1, 0 <= G_S[s][id] <= N_P - 1) 	
 -- int *** P3.G_R       : product number for store s and request r, G_R[s][r][id] 
                          ( s = 0, 1, ..., N_S - 1, r = 0, 1, ..., N_R[ s ] - 1, id = 0, 1, ..., N_G_R[ s ][ r ] - 1, 0 <= G_R[s][r][id] <= N_P - 1 )
 -- int     P3.Y_S_BASE  : offset of y_S[] to y[], y_S[0] is y[ Y_S_BASE ]
 -- int     P3.Y_R_BASE  : offset of y_R[] to y[], y_R[0] is y[ Y_R_BASE ]
 -- int     P3.Y_K_BASE  : offset of y_K[] to y[], y_K[0] is y[ Y_K_BASE ]
 -- int     P3.Y_P_BASE  : offset of y_P[] to y[], y_P[0] is y[ Y_P_BASE ]
 -- int     P3.Y_T_BASE  : offset of y_T[] to y[], y_T[0] is y[ Y_T_BASE ]
 -- int *   P3.N_R_BASE  : offset of y_R[] in store s to y_R[0], y_R[ N_R_BASE[s] ]
                           ( s = 0, 1, ..., N_S - 1 )
 -- int     P3.ERR_VALUE : return value in case error occurs ( < 0 )

References

[1] C. Kondo, Y. Kawano, and H. Iima : "An Optimization Benchmark Problem for Autimatic Picking System Operational Planning and Schedule," Proc. of IEEJ Conference on Electronics, Information, and Systems 2012 (Sep. 2011) [ in Japanese ]
[2] Investigating R&D committee on new development of computational intelligence techniques and their applications to industrial systems Eds. : "Optimization Benchmark Problems for Industrial Applications," IEEJ Tech. Rep. No. 1287 (Jul. 2013) [in Japanese]
[3] H. Iima, and Y. Kawano : "Operational Planning and Scheduling Benchmark Problem in Automatic Picking System," Proc. of the 2014 Annual Meeting on the Institute of Electrical Engineers of Japan (Mar. 2014) [in Japanese]
[4] H. Iima, Y. Koguma, and Y. Kawano : "Operational Planning and Scheduling Benchmark Problem in an Automatic Picking System for Metaheuristics," Proc. of Scheduling Symposium 2014 (Sep. 2014) [in Japanese]


