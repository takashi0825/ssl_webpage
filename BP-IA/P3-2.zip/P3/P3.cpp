/*
 * An optimization benchmark problem for the automatic picking system operational planning problem
 * (main file)
 * These codes are edited by the investigating R&D committee on new development of computational intelligence 
 * techniques and their applications to industrial systems, the institute of electrical engineers of Japan.
 * Contact : Takashi Okamoto (takashi@faculty.chiba-u.jp)
 * Last update on Jul. 19th, 2015
 */
#include "P3.h"
#include <iostream>
#include <fstream>
using namespace std;


/* Constructor */
P3::P3
(
	const std::string	&	file_name
)
{
	// Set Constants
	initialization();

	/* Set common variables */
	N_x			= 0;
	P			= 1;

	S_P			= new int	[ N_P ];
	R_P			= new int	[ N_P ];
	K_P			= new int	[ N_P ];

	read_Data( file_name );

	m_G_P		= new int	[ N_P ];

	N_R			= new int	[ N_S ];
	N_R_BASE	= new int	[ N_S ];

	for( int p = 0 ; p < N_P ; p++ )
	{
		m_G_P[p]	= p;
	}

	int		s	= 0;
	int		r	= 0;
	N_R[ 0 ]	= 1;
	for( int p = 0 ; p < N_P ; p++ )
	{
		if( s != S_P[ p ] )
		{
			s++;
			N_R[ s ]	= 1;
			r			= 0;
		}
		else if( r != R_P[ p ] )
		{
			N_R[ s ]++;
			r++;
		}
	}

	N_R_BASE[ 0 ]	= 0;
	for( int s = 1 ; s < N_S ; s++ )
	{
		N_R_BASE[ s ]	= N_R_BASE[ s - 1 ] + N_R[ s - 1 ] * N_R[ s - 1 ];	 
	}

	Y_S_BASE	=	0;
	Y_R_BASE	=	Y_S_BASE + N_S * N_S;
	Y_K_BASE	=	Y_R_BASE + N_R_BASE[ N_S - 1 ] + N_R[ N_S - 1 ] * N_R[ N_S - 1 ];
	Y_P_BASE	=	Y_K_BASE + N_L * N_K;
	Y_T_BASE	=	Y_P_BASE + N_L * N_P;

	N_y			=	Y_T_BASE + N_P;

	sort_G_P( 0, N_P - 1 );

	N_G_S		= new	int		[ N_S ];
	G_S			= new 	int *	[ N_S ];

	N_G_R		= new	int *	[ N_S ];
	G_R			= new 	int **	[ N_S ];

	for( int s = 0 ; s < N_S ; s++ )
	{
		N_G_R[ s ]		= new	int		[ N_R[ s ] ];
		G_R[ s ]		= new 	int *	[ N_R[ s ] ];
	}

	set_Group();

	count_Conditions();

	m_Min_CP_S	= new	int		[ N_S ];
	m_Max_CP_S	= new	int		[ N_S ];
	m_Min_CP_R	= new	int *	[ N_S ];
	m_Max_CP_R	= new	int	*	[ N_S ];
	for( int s = 0 ; s < N_S ; s++ )
	{
		m_Min_CP_R[ s ]	= new	int		[ N_R[ s ] ];
		m_Max_CP_R[ s ]	= new 	int 	[ N_R[ s ] ];
	}
}


/* destructor */
P3::~P3()
{
	for( int s = 0 ; s < N_S ; s++ )
	{
		delete	[]	m_Max_CP_R[ s ];
		delete	[]	m_Min_CP_R[ s ];
	}
	delete	[]	m_Max_CP_R;
	delete	[]	m_Min_CP_R;
	delete	[]	m_Max_CP_S;
	delete	[]	m_Min_CP_S;

	for( int s = 0 ; s < N_S ; s++ )
	{
		delete	[]	G_R[ s ];
		delete	[]	N_G_R[ s ];
	}

	delete	[]	G_R;
	delete	[]	N_G_R;
	delete	[]	G_S;
	delete	[]	N_G_S;
	delete	[]	N_R_BASE;
	delete	[]	N_R;
	delete	[]	m_G_P;
	delete	[]	K_P;
	delete	[]	R_P;
	delete	[]	S_P;
}


/* evaluation function */
void	P3::evaluation
( 
	double *	x, 
	double *	y, 
	double *	f, 
	double *	g, 
	double *	h 
)
{
	int		id_f	= 0;
	int		id_g	= 0;
	int		id_h	= 0;
	int		id_y	= 0;
	double	value	= 0;

	//compute objective function */ 
	//Eq. (10)
	f[ id_f ]	= 0;
	for( int p = 0 ; p < N_P ; p++ ) 
	{
		int	cp	= C_P( p, &y[ Y_P_BASE ], &y[ Y_T_BASE ] );

		if( f[ id_f ] < cp )
		{
			f[ id_f ]	= cp;
		}
	}
	f[ id_f ]	= ( f[ id_f ] + 1 ) / alpha; 

	/* compute constraint conditions */
	//Eq. (11)
	for( int u = 0 ; u < N_S ; u++ ) 
	{
		value = 0;
		for( int s = 0 ; s < N_S ; s++ ) 
		{
			value		+= y[ Y_S_BASE + s * N_S + u ];		//	y_S[s][u]
		}
		h[ id_h++ ]	= value - 1;
	}

	//Eq. (12)
	for( int s = 0 ; s < N_S ; s++ ) 
	{
		value = 0;
		for( int u = 0 ; u < N_S ; u++ ) 
		{
			value		+= y[ Y_S_BASE + s * N_S + u ];		//	y_S[s][u]
		}
		h[ id_h++ ]	= value - 1;
	}

	//Eq. (13)
	for( int s = 0 ; s < N_S ; s++ ) 
	{
		for( int v = 0 ; v < N_R[s] ; v++ ) 
		{
			value = 0;
			for( int r = 0 ; r < N_R[s] ; r++ ) 
			{
				value		+= y[ Y_R_BASE + N_R_BASE[s] + r * N_R[s] + v ];	//	y_R[s][r][v]
			}
			h[ id_h++ ]	= value - 1;
		}
	}

	//Eq. (14)
	for( int s = 0 ; s < N_S ; s++ ) 
	{
		for( int r = 0 ; r < N_R[s] ; r++ ) 
		{
			value = 0;
			for( int v = 0 ; v < N_R[s] ; v++ ) 
			{
				value		+= y[ Y_R_BASE + N_R_BASE[s] + r * N_R[s] + v ];	//	y_R[s][r][v]
			}
			h[ id_h++ ]	= value - 1;
		}
	}

	//Eq. (15)
	for( int l = 0 ; l < N_L ; l++ ) 
	{
		value = 0;
		for( int k = 0 ; k < N_K ; k++ ) 
		{
			value	+= y[ Y_K_BASE + l * N_K + k ];		//	y_K[l][k]
		}
		g[ id_g++ ]	= value - 1;
	}

	//Eq. (16)
	for( int p = 0 ; p < N_P ; p++ ) 
	{
		value = 0;
		for( int l = 0 ; l < N_L ; l++ ) 
		{
			value	+= y[ Y_P_BASE + l * N_P + p ];		//	y_P[l][p]
		}
		h[ id_h++ ]	= value - 1;
	}

	//Eq. (17)
	for( int p = 0 ; p < N_P ; p++ ) 
	{
		value = 0;
		for( int l = 0 ; l < N_L ; l++ ) 
		{
			value	+= y[ Y_P_BASE + l * N_P + p ] * y[ Y_K_BASE + l * N_K + K_P[ p ] ];	//	y_P[l][p] * y_K[l][K_P[p]-1]
		}
		h[ id_h++ ]	= value - 1;
	}

	//Eq. (18)
	for( int s = 0 ; s < N_S ; s++ ) 
	{
		for( int r = 0 ; r < N_R[s] ; r++ ) 
		{
			for( int n2 = 0 ; n2 < N_G_R[s][r] ; n2++ ) 
			{
				int		p2		= G_R[s][r][n2];
				int		cpmin	= -1; 
				for( int n1 = 0 ; n1 < N_G_R[s][r] ; n1++ ) 
				{
					int	p1	= G_R[s][r][n1];

					if( p1 != p2 )
					{
						int	c	= abs(	C_P( p1, &y[ Y_P_BASE ], &y[ Y_T_BASE ] ) 
								-		C_P( p2, &y[ Y_P_BASE ], &y[ Y_T_BASE ] ) );
						if(		( cpmin < 0 )	
							||	( c < cpmin	) )
						{
							cpmin	= c;
						}
					}
				}
				g[ id_g++ ]	= cpmin - beta;
			}
		}
	}

	//Eq. (19) min-max
	for( int s = 0 ; s < N_S ; s++ ) 
	{
		m_Min_CP_S[ s ]	= -1;
		m_Max_CP_S[ s ]	= -1;

		for( int n = 0 ; n < N_G_S[ s ] ; n++ ) 
		{
			int p	= G_S[ s ][ n ];
			int	cp	= C_P( p, &y[ Y_P_BASE ], &y[ Y_T_BASE ] );

			if( m_Min_CP_S[ s ] < 0 || cp < m_Min_CP_S[ s ] )
			{
				m_Min_CP_S[ s ]	= cp;
			}
			if( m_Max_CP_S[ s ] < 0 || cp > m_Max_CP_S[ s ] )
			{
				m_Max_CP_S[ s ]	= cp;
			}
		}
	}

	for(int u = 0 ; u < N_S-1 ; u++ )
	{
		int s1 = S_U(u  , &y[ Y_S_BASE ] );
		int s2 = S_U(u+1, &y[ Y_S_BASE ] );
		g[ id_g ++ ] =  m_Max_CP_S[ s1 ] - m_Min_CP_S[ s2 ] + beta;
	}

	//Eq. (20) min-max 
	for( int s = 0 ; s < N_S ; s++ ) 
	{
		for( int r = 0 ; r < N_R[ s ] ; r++ ) 
		{
			m_Min_CP_R[ s ][ r ]	= -1;
			m_Max_CP_R[ s ][ r ]	= -1;

			for( int n = 0 ; n < N_G_R[ s ][ r ] ; n++ ) 
			{
				int p	= G_R[ s ][ r ][ n ];
				int	cp	= C_P( p, &y[ Y_P_BASE ], &y[ Y_T_BASE ] );

				if( m_Min_CP_R[ s ][ r ] < 0 || cp < m_Min_CP_R[ s ][ r ] )
				{
					m_Min_CP_R[ s ][ r ]	= cp;
				}
				if( m_Max_CP_R[ s ][ r ] < 0 || cp > m_Max_CP_R[ s ][ r ] )
				{
					m_Max_CP_R[ s ][ r ]	= cp;
				}
			}
		}
	}

	for(int s = 0 ; s < N_S ; s++ )
	{
		for( int v = 0 ; v < N_R[ s ] - 1 ; v++ )
		{		
			int r1 = R_V(s, v  , &y[ Y_R_BASE ] );
			int r2 = R_V(s, v+1, &y[ Y_R_BASE ] );

			g[ id_g++ ] =  m_Max_CP_R[ s ][ r1 ] - m_Min_CP_R[ s ][ r2 ] + beta;

		}
	}

	//Eq. (21)
	for( int s = 0 ; s < N_S ; s++ ) 
	{
		for( int r = 0 ; r < N_R[s] ; r++ ) 
		{
			for( int n2 = 0 ; n2 < N_G_R[ s ][ r ] ; n2++ ) 
			{
				int p2	= G_R[ s ][ r ][ n2 ];
				for( int n1 = 0 ; n1 < N_G_R[ s ][ r ] ; n1++ ) 
				{
					int p1	= G_R[ s ][ r ][ n1 ];

					if( p1 < p2 )
					{
						g[ id_g++ ]	= -abs( C_P( p1, &y[ Y_P_BASE ], &y[ Y_T_BASE ] ) 
									-		C_P( p2, &y[ Y_P_BASE ], &y[ Y_T_BASE ] ) );
					}
				}
			}
		}
	}
}

/* check feasibility */
bool	P3::checkFeasibility
(
	double *	x, 
	double *	y
)
{
	bool		feasibility = false;
	double *	f			= 0;
	double *	g			= 0;
	double *	h			= 0;

	/* check feasibility of y */
	for( int n = 0 ; n < N_y - N_P; n++ ) 
	{
		if( y[n] < 0 || 1 < y[n] ) 
		{
			return( feasibility );
		}
	}

	for( int n = N_y - N_P ; n < N_y ; n++ ) 
	{
		if( y[n] < 0 ) 
		{
			return( feasibility );
		}
	}

	/* compute f, g, and h */
	f	= new double	[ P ];
	g	= new double	[ M ];
	h	= new double	[ Q ];

	evaluation( x, y, f, g, h );

	feasibility = true;

	/* check inequality conditions */
	for( int m = 0 ; m < M ; m++ ) 
	{
		if( g[m] > eps ) 
		{
			feasibility = false;
			break;
		}
	}

	if( true == feasibility )
	{
		/* check equality conditions */
		for( int q = 0 ; q < Q ; q++ ) 
		{
			if( fabs( h[q] ) > eps )
			{
				feasibility = false;
				break;
			}
		}
	}

	/* memory release */
	delete	[]	f;
	delete	[]	g;
	delete	[]	h;

	return( feasibility );
}

int		P3::S_U		// Eq. (6)
( 
	const	int			u,
	const	double *	y_S
)	const
{
	int		s_value		= 0;
	int		count		= 0;
	int		y_S_value	= 0;

	for( int s = 0 ; s < N_S ; s++ ) 
	{
		switch( y_S_value	= (int)y_S[ s * N_S + u ] )
		{
		case 1:
			count++;
			break;
		case 0:
			break;
		default:
			return( ERR_VALUE );
		}

		if( y_S_value	!= y_S[ s * N_S + u ] )
		{
			return( ERR_VALUE );
		}

		s_value		+= s * y_S_value;			//	s * y_S[s][u]
	}

	if( count != 1 )
	{
		return( ERR_VALUE );
	}

	return( s_value );
}

int		P3::R_V		// Eq. (7)
( 
	const	int			s, 
	const	int			v, 
	const	double *	y_R
)	const
{
	int		r_value		= 0;
	int		count		= 0;
	int		y_R_value	= 0;

	for( int r = 0 ; r < N_R[ s ] ; r++ ) 
	{
		switch( y_R_value	= (int)y_R[ N_R_BASE[ s ] + r * N_R[ s ] + v ] )
		{
		case 1:
			count++;
			break;
		case 0:
			break;
		default:
			return( ERR_VALUE );
		}

		if( y_R_value	!= y_R[ N_R_BASE[ s ] + r * N_R[ s ] + v ] )
		{
			return( ERR_VALUE );
		}

		r_value	+= r * y_R_value;	//	y_R[s][r][v]
	}

	if( count != 1 )
	{
		return( ERR_VALUE );
	}

	return( r_value );
}


int		P3::L_P		// Eq. (8)
( 
	const	int			p,
	const	double *	y_P
)	const
{
	int		c_value		= 0;
	int		count		= 0;
	int		y_P_value	= 0;

	for( int l = 0 ; l < N_L ; l++ ) 
	{
		switch( y_P_value	= (int)y_P[ l * N_P + p ] )
		{
		case 1:
			count++;
			break;
		case 0:
			break;
		default:
			return( ERR_VALUE );
		}

		if( y_P_value	!= y_P[ l * N_P + p ] )
		{
			return( ERR_VALUE );
		}

		c_value	+= l * y_P_value;
	}

	if( count != 1 )
	{
		return( ERR_VALUE );
	}

	return( c_value );
}

int		P3::C_P		// Eq. (9)
( 
	const	int			p,
	const	double *	y_P,
	const	double *	y_T
)	const
{
	int		c_value		= 0;
	int		y_T_value	= 0;

	y_T_value	= (int)y_T[ p ];
	if( y_T_value	!=  y_T[ p ] )
	{
		return( ERR_VALUE );
	}

	c_value	= L_P(p, y_P) + alpha * y_T_value;

	return( c_value );
}

/* Private methods */
void	P3::initialization()
{
	//Read constants
	std::ifstream ifs;
	ifs.open("P3_constants.conf");
	std::string tmp;

	ifs >> tmp >> N_L;
	ifs >> tmp >> N_K;
	ifs >> tmp >> N_S;
	ifs >> tmp >> N_P;
	ifs >> tmp >> alpha;
	ifs >> tmp >> beta;

	ifs.close();

	//Read tolerance for constraint violations
	ifs.open("P3_tolerance.conf");
	ifs >> eps;
	ifs.close();
}

void	P3::set_Group( void )
{
	int		s	= 0;
	int		r	= 0;

	N_G_S[ s ]		= 0;
	N_G_R[ s ][ r ]	= 0;

	G_S[ s ]		= &m_G_P[ 0 ];
	G_R[ s ][ r ]	= &m_G_P[ 0 ];

	for( int p = 0 ; p < N_P ; p++ )
	{
		if( s != S_P[ p ] )
		{
			s++;
			N_G_S[ s ]		= 1;
			G_S[ s ]		= &m_G_P[p];
			r				= 0;
			N_G_R[ s ][ r ]	= 1;
			G_R[ s ][ r ]	= &m_G_P[p];
		}
		else if( r != R_P[ p ] )
		{
			N_G_S[ s ]++;
			r++;
			N_G_R[ s ][ r ]	= 1;
			G_R[ s ][ r ]	= &m_G_P[ p ];
		}
		else
		{
			N_G_S[ s ]++;
			N_G_R[ s ][ r ]++;
		}
	}
}


void	P3::read_Data
(
	const	std::string	&	file_name
)
{
	std::ifstream ifs(file_name.c_str());
	char		buf[ 1024 ];
	int			p		= 0;
	int			n;
	int			s;
	int			r;
	int			k;

	ifs >> buf;

	while( !( ifs.eof() ) )
	{
		ifs >> buf;
		if( 4 != sscanf( buf, "%d,%d,%d,%d", &n, &s, &r, &k ) )
		{
				break;
		}

		for( int i = 0 ; i < n ; i++ )
		{
			S_P[ p ]	= s - 1;
			R_P[ p ]	= r - 1;
			K_P[ p ]	= k - 1;
			p++;
		}
	}

	ifs.close();
}	

void	P3::sort_G_P
( 
	const	int		Start, 
	const	int		End
)
{
	int		p1;
	int		p2;
	int		p3;
	int		tmp;
    
    if( Start >= End)
	{
		return;
	}
	    
    p1 = Start;
    p2 = End;

	p3 = ( Start + End ) / 2;
    
    while(1)
	{    
        while( compare_G_P( p1, p3 ) < 0 )	{	p1++;	}
        while( compare_G_P( p2, p3 ) > 0 )	{	p2--;	}
        
        if( p1 >= p2 )
		{
			break;
		}

        tmp			= m_G_P[ p1 ];
        m_G_P[ p1 ]	= m_G_P[ p2 ];
        m_G_P[ p2 ]	= tmp;
        p1++;
        p2--;
	}
    
    sort_G_P( Start,  p1 - 1 );
    sort_G_P( p2 + 1, End    );
}

int		P3::compare_G_P
(
	const	int		p1,
	const	int		p2
)
{

	if(		 ( S_P[ p1 ] < S_P[ p2 ] ) )	{	return( -1 );	}
	else if( ( S_P[ p1 ] > S_P[ p2 ] ) )	{	return( +1 );	}
	else if( ( R_P[ p1 ] < R_P[ p2 ] ) )	{	return( -1 );	}
	else if( ( R_P[ p1 ] > R_P[ p2 ] ) )	{	return( +1 );	}
	else if( ( K_P[ p1 ] < K_P[ p2 ] ) ) 	{	return( -1 );	}
	else if( ( K_P[ p1 ] > K_P[ p2 ] ) ) 	{	return( +1 );	}
	else if( (      p1   <      p2	 ) )	{	return( -1 );	}
	else if( (      p1   >      p2	 ) )	{	return( +1 );	}

	return( 0 );
}

void	P3::count_Conditions( void )
{
	int		id_g	= 0;
	int		id_h	= 0;

	/* compute constraint conditions */

	id_h	+= N_S;								//Eq. (11)
	id_h	+= N_S;								//Eq. (12)
							
	for( int s = 0 ; s < N_S ; s++ )			//Eq. (13)
	{
		id_h	+= N_R[s];						
	}

	for( int s = 0 ; s < N_S ; s++ )			//Eq. (14)
	{
		id_h	+= N_R[s];						
	}

	id_g	+= N_L;								//Eq. (15)
	id_h	+= N_P;								//Eq. (16)
	id_h	+= N_P;								//Eq. (17)
	id_g	+= N_P;								//Eq. (18)
	
	//Eq. (19) min-max
	id_g	+= ( N_S - 1 );

	//Eq. (20) min-max 
	for( int s = 0 ; s < N_S ; s++ ) 
	{
		id_g	+= ( N_R[ s ] - 1 );
	}

	for( int s = 0 ; s < N_S ; s++ )			//Eq. (21)
	{
		for( int r = 0 ; r < N_R[ s ] ; r++ ) 
		{
			id_g	+= N_G_R[ s ][ r ] * ( N_G_R[ s ][ r ] - 1 ) / 2;
		}
	}

	M	= id_g;
	Q	= id_h;
}