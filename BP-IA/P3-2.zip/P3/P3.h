/*
 * An optimization benchmark problem for the automatic picking system operational planning problem
 * (header file)
 * These codes are edited by the investigating R&D committee on new development of computational intelligence 
 * techniques and their applications to industrial systems, the institute of electrical engineers of Japan.
 * Contact : Takashi Okamoto (takashi@faculty.chiba-u.jp)
 * Last update on Jul. 19th, 2015
 * 
 * Variables
 *  x : continuous decision variables
 *  y : discrete decision variables
 *  N_x : number of continuous decision variables
 *  N_y : number of discrete decision variables
 *  P : number of objective funcitons
 *  M : number of inequality conditions
 *  Q : number of equality conditions
 *  eps : tolerance for constraint violations
 *
 * Funcitons
 *  "evaluation" sets objective function values to f, 
 *  inequality condition function values to g, and 
 *  equality condition function values to h.
 *  "checkFeasibility" returns feasibility of decision variables
 */
#include <float.h>
#include <stdlib.h>
#include <cmath>
#include <string>
#include <fstream>

class P3 {
public:
	//constructor
	P3
	(
		const std::string	&	file_name	//	file name of dataset
	);

	//destructor
	virtual ~P3();

public:
	//constants
	int		N_x;					//	number of continuous decision variables
	int		N_y;					//	number of discrete decision variables,	
	int		P;						//	number of objective funcitons
	int		M;						//	number of inequality conditions,		
	int		Q;						//	number of equality conditions,			
	double	eps;					//	tolerance for constraint violations

	int		N_L;					//	number of lanes
	int		N_K;					//	number of kinds of products
	int		N_S;					//	number of stores
	int		N_P;					//	number of products
	int		alpha;					//	speed of conveyer 
	int		beta;					//	minimum space on conveyer between products of 
									//		different requests
	int *	N_R;					//	number of requests in store S,	N_R[s], 
									//		( s = 0, 1, ..., N_S - 1 ) 

	int *	S_P;					//	the store number s of product number p ( s = S_P[ p ],
									//		p = 0, 1, ..., N_P - 1, 0 <= s <= N_S - 1 )  	
	int *	R_P;					//	the request number r of product number p 
									//		( r = R_P[ p ], p = 0, 1, ..., N_P - 1, 
									//		0 <= r <= N_R[ S_P[ p ] ] - 1 )
	int *	K_P;					//	the kind number k of product number p ( k = K_P[ p ], 
									//		p = 0, 1, ..., N_P - 1, 0 <= k <= N_K - 1 )

	int *	N_G_S;					//	number of products for store s, N_G_S[ s ],  
									//		( s = 0, 1, ..., N_S - 1 )
	int **	N_G_R;					//	number of products for store s and request r, 
									//		N_G_R[ s ][ r ],  ( s = 0, 1, ..., N_S - 1, 
									//		r = 0, 1, ..., N_R[ s ] - 1 )
	int **	G_S;					//  product number for store s, G_S[s][id], 
									//		( s = 0, 1, ..., N_S - 1, 
									//		id = 0, 1, ..., N_G_S[ s ] - 1, 
									//		0 <= G_S[s][id] <= N_P - 1 	
	int ***	G_R;					//	product number for store s and request r, G_R[s][r][id]
									//		( s = 0, 1, ..., N_S - 1, r = 0, 1, ..., N_R[ s ] - 1
									//		id = 0, 1, ..., N_G_R[ s ][ r ] - 1, 
									//		0 <= G_R[s][r][id] <= N_P - 1 )

	int		Y_S_BASE;				//	offset of y_S[] to y[], y_S[0] is y[ Y_S_BASE ]
	int		Y_R_BASE;				//	offset of y_R[] to y[], y_R[0] is y[ Y_R_BASE ]
	int		Y_K_BASE;				//	offset of y_K[] to y[], y_K[0] is y[ Y_K_BASE ]
	int		Y_P_BASE;				//	offset of y_P[] to y[], y_P[0] is y[ Y_P_BASE ]
	int		Y_T_BASE;				//	offset of y_T[] to y[], y_T[0] is y[ Y_T_BASE ]
	int *	N_R_BASE;				//	offset of y_R[] in store s to y_R[0], 
									//		y_R[ N_R_BASE[s] ], ( s = 0, 1, ..., N_S - 1 )
	int		ERR_VALUE;				//	return value in case error occurs ( < 0 )

	//public methods
	void	evaluation				//	sets objective function values to f, 
	(								//	inequality condition function values to g, 
									//	and equality condition function values to h.
			double *		x,		//	IN:  continuous decision variables,			
									//			x[ 0 ], x[ 1 ], ... , x[ N_x - 1 ]
			double *		y,		//	IN:	 discrete decision variables,
									//			y[ 0 ], y[ 1 ], ... , y[ N_y - 1 ]
			double *		f,		//	OUT: objective funciton function values,	
									//			f[ 0 ], f[ 1 ], ... , f[ P   - 1 ]
			double *		g, 		//	OUT: inequality condition function values,	
									//			g[ 0 ], g[ 1 ], ... , g[ M   - 1 ]
			double *		h		//	OUT: equality condition function values,	
									//			h[ 0 ], h[ 1 ], ... , h[ Q   - 1 ]
	);
	
	bool	checkFeasibility		//	returns feasibility of decision variables
	(								//	true:	feasible,	false:	infeasible
			double *		x, 		//	IN:  continuous decision variables,			
									//			x[ 0 ], x[ 1 ], ... , x[ N_x - 1 ]
			double *		y 		//	IN:	 discrete decision variables,			
									//			y[ 0 ], y[ 1 ], ... , y[ N_y - 1 ]
	);


	int		S_U		// Eq. (6)   	//	returns the store number s which is done in order u, 
	(								//		( 0 <= s <= N_S - 1 ) 
		const	int			u,		//	the order to do in a store. ( u = 0, 1, ..., N_S - 1 )
		const	double *	y_S		//	discrete decision variables y_S, 
									//		( y_S[0], y_S[1], ..., y_S[ N_S * N_S - 1 ] )
	)	const;						//	y_S[] must be feasible to calculate correctly.


	int		R_V		// Eq. (7)	    //	returns the request number r in store s which is done 
	(								//		in order v, ( 0 <= r <= N_R[ s ] - 1 )
		const	int			s,		//	the store number,		( s = 0, 1, ..., N_S - 1		)
		const	int			v,		//	the order to do in a request in store number s. 
									//		( v = 0, 1, ..., N_R[ s ] - 1 )
		const	double *	y_R		//	discrete decision variables y_R, 
									//		( y_R[0], y_R[1], ..., y_R[ Y_K_BASE-Y_R_BASE-1 ] )
	)	const;						//	y_R[] must be feasible to calculate correctly.

	int		L_P		// Eq. (8)	    //	returns the lane number to which the product p assigned, 
	(								//		( L_P(p) = 0, 1, ... ) 
		const	int			p,		//	the product number, ( p = 0, 1, ..., N_P - 1 )
		const	double *	y_P 	//	discrete decision variables y_P, 
									//		( y_P[0], y_P[1], ..., y_P[ N_P * N_L - 1 ] )
	)	const;						//	y_P[] must be feasible to calculate correctly. 

	int		C_P		// Eq. (9)	    //	returns the imaginary conveyer position which discharges the product p,
	(								//		( C_P(p) = 0, 1, ... ) 
		const	int			p,		//	the product number, ( p = 0, 1, ..., N_P - 1 )
		const	double *	y_P,	//	discrete decision variables y_P, 
									//		( y_P[0], y_P[1], ..., y_P[ N_P * N_L - 1 ] )
		const	double *	y_T		//	discrete decision variables y_T, 
									//		( y_T[0], y_T[1], ..., y_T[ N_P - 1 ] )
	)	const;						//	y_P[] and y_T[] must be feasible to calculate correctly. 


private:
	//private methods
	void	initialization( void );		//	initialize each value of member variables

	void	count_Conditions( void );	//	count inequality conditions and equality conditions
										//	IN:		N_R[], N_G_S[], N_G_R[][], G_S[][], G_R[][][]
										//	OUT:	M, G

	void	set_Group( void );			//	groupiong products in each store and request 
										//	IN:		S_P[], R_P[], G_P[],	
										//	OUT:	N_G_S[], N_G_R[][], G_S[][], G_R[][][]

	void	read_Data					//	read the data file into variables 
										//			S_P[], R_P[] and K_P[] 
										//	IN:		data file,
										//	OUT:	S_P[], R_P[], K_P[] 
	(
		const	std::string	&	file_name	//	file name of dataset
	);

	void	sort_G_P					//	sort G_P[] data according to the order of store,
										//		request and kind of product  
	(									//	IN:		S_P[], R_P[], K_P[], G_P[]
										//	OUT:	G_P[]
		const	int			Start,		//	the first product number to sort	
										//		( 0, 1, ..., N_P - 1 )
		const	int			End			//	the last  product number to sort	
										//		( 0, 1, ..., N_P - 1 )
	);

	int		compare_G_P					//	returns the result of the orders of both products 
	(									//	+1 : p1 is earlier , -1 : p2 is earlier , 
										//	0: the same order
		const	int			p1,			//	product number	( 0, 1, ..., N_P - 1 )
		const	int			p2			//	product number	( 0, 1, ..., N_P - 1 )
	);

	//private members
	int *		m_G_P;				//	product number array data for grouping, m_G_P[ p ], 
									//		( p = 0, 1, ..., N_P - 1, 0 <= m_G_P[p] <= N_P - 1 )
	int *		m_Min_CP_S;			//	minimum conveyer's position of group G_S[ s ],
									//		( s = 0, 1, ..., N_S - 1 ) 
	int *		m_Max_CP_S;			//	maximum conveyer's position of group G_S[ s ],  
									//		( s = 0, 1, ..., N_S - 1 )
	int **		m_Min_CP_R;			//	minimum conveyer's position of group G_R[ s ][ r ],
									//		( s = 0, 1, ..., N_S - 1, 
									//		  r = 0, 1, ..., N_R[ s ] - 1 )
	int **		m_Max_CP_R;			//	maximum conveyer's position of group G_R[ s ][ r ],
									//		( s = 0, 1, ..., N_S - 1, 
									//		  r = 0, 1, ..., N_R[ s ] - 1 )
};
