/*
 * P3 class sample
 * These codes are edited by the investigating R&D committee on new development of computational intelligence 
 * techniques and their applications to industrial systems, the institute of electrical engineers of Japan.
 * Contact : Takashi Okamoto (takashi@faculty.chiba-u.jp)
 * Last update on Jul. 19th, 2015
 */
#include "P3.h"
#include <iostream>
#include <fstream>
using namespace std;

static	void	P3_out_x( ostream &	out, const P3 *	OF,	const double *	x );
static	void	P3_out_y( ostream &	out, const P3 * OF,	const double *	y );
static	void	P3_out_f( ostream &	out, const P3 *	OF,	const double *	f );
static	void	P3_out_g( ostream &	out, const P3 *	OF,	const double *	g );
static	void	P3_out_h( ostream & out, const P3 *	OF,	const double *	h );
static	void	P3_out_cp(ostream &	out, const P3 *	OF,	const double *	y );


int main()
{
	//preparation
	double	*	x;
	double	*	y;
	double	*	f;
	double	*	g;
	double	*	h;				//variable declaration
	P3 *		OF;				//create P3 class instance
	bool		feasibility;

	OF	= new P3( "P3_data.csv" );

	ifstream	ifs(    "P3_solution_y.txt" );
	ofstream	x_fout( "P3_result_x.txt"  );
	ofstream	y_fout( "P3_result_y.txt"  );
	ofstream	f_fout( "P3_result_f.txt"  );
	ofstream	g_fout( "P3_result_g.txt"  );
	ofstream	h_fout( "P3_result_h.txt"  );
	ofstream	c_fout( "P3_result_c.txt"  );

	x	= new double [ OF->N_x ];	//memory allocation for x
	y	= new double [ OF->N_y ];	//memory allocation for y
	f	= new double [ OF->P   ];	//memory allocation for f
	g	= new double [ OF->M   ];	//memory allocation for g
	h	= new double [ OF->Q   ];	//memory allocation for h

	// read a sample solution from P3_solution_y.txt.
	for ( int n = 0 ; n < OF->N_y ; n++ ) 
	{
		if( ifs.eof() )
		{
			break;
		}
		ifs >> y[n];
	}

	cout << "N_x = " <<  OF->N_x << endl;
	cout << "N_y = " <<  OF->N_y << endl;
	cout << "P   = " <<  OF->P   << endl;
	cout << "M   = " <<  OF->M   << endl;
	cout << "Q   = " <<  OF->Q   << endl;

	//evaluation
	OF->evaluation( x, y, f, g, h );
	double V = 0.0;
	for (int m = 0; m < OF->M; m++) {
		if (g[m] > 0.0) {
			V += g[m];
		}
	}
	for (int q = 0; q < OF->Q; q++) {
		V += fabs(h[q]);
	}

	feasibility	= OF->checkFeasibility( x, y );

	cout << "f1 = " <<  ( f[ 0 ] ) << endl;
	cout << "Sum of violation = " << V << endl;
	cout << "Input solution is " << ( feasibility ? "feasible" : "infeasible" ) << "." << endl;

	P3_out_x(  x_fout, OF, x	);
	P3_out_y(  y_fout, OF, y 	);
	P3_out_f(  f_fout, OF, f	);
	P3_out_g(  g_fout, OF, g	);
	P3_out_h(  h_fout, OF, h	);
	P3_out_cp( c_fout, OF, y	);

	delete	[]	h;
	delete	[]	g;
	delete	[]	f;
	delete	[]	y;
	delete	[]	x;

	delete		OF;

	return 0;
}

static	void	P3_out_x
(
	ostream &			out,
	const P3 *	OF,
	const	double *	x
)
{
	out << "x = " << endl;
	for (int n = 0; n < OF->N_x; n++) 
	{
		out << x[ n ] << " ";
	}
	out << endl;
}

static	void	P3_out_f
(
	ostream &			out,
	const P3 *			OF,
	const	double *	f
)
{
	for (int p = 0; p < OF->P; p++) 
	{
		out << "f" << p + 1 << " = " << f[ p ] << endl;
	}
}

static	void	P3_out_g
(
	ostream &			out,
	const P3 *			OF,
	const	double *	g
)
{
	int	id_g	= 0;

	out << "Eq. (15)" << endl;
	for( int l = 0 ; l < OF->N_L ; l++ ) 
	{
		out << "g" << id_g + 1 << "( l = " << l + 1 << " ) = ";
		out << g[ id_g++ ] << endl;
	}

	out << "Eq. (18)" << endl;
	for( int s = 0 ; s < OF->N_S ; s++ ) 
	{
		out << "s = " << s + 1 << endl;
		for( int r = 0 ; r < OF->N_R[s] ; r++ ) 
		{
			out << "r = " << r + 1 << endl;
			for( int n2 = 0 ; n2 < OF->N_G_R[ s][ r ] ; n2++ ) 
			{
				int		p1		= OF->G_R[ s ][ r ][ n2 ];

				out << "g" << id_g + 1 << "( p1 = " << p1 + 1 << " ) = ";
				out << g[ id_g++ ] << endl;
			}
		}
	}
	
	out << "Eq. (19)" << endl;	
	for(int u = 0 ; u < OF->N_S-1 ; u++ )
	{
		out << "g" << id_g + 1 << "( u1 = " << u + 1 << " , u2 = " << u + 2 << " ) = ";
		out << g[ id_g++ ] << endl;
	}

	out << "Eq. (20)" << endl;
	for(int s = 0 ; s < OF->N_S ; s++ )
	{
		for( int v = 0 ; v < OF->N_R[ s ] - 1 ; v++ )
		{		
			out << "g" << id_g + 1  << "( s = " << s + 1 << ", v1 = " << v + 1 << " , v2 = " << v + 2 << " ) = ";
			out << g[ id_g++ ] << endl;
		}
	}

	out << "Eq. (21)" << endl;
	for( int s = 0 ; s < OF->N_S ; s++ ) 
	{
		out << "s = " << s + 1 << endl;

		for( int r = 0 ; r < OF->N_R[ s ] ; r++ ) 
		{
			out << "r = " << r + 1 << endl;

			for( int n2 = 0 ; n2 < OF->N_G_R[ s ][ r ] ; n2++ ) 
			{
				int p2	= OF->G_R[ s ][ r ][ n2 ];
				for( int n1 = 0 ; n1 < OF->N_G_R[ s ][ r ] ; n1++ ) 
				{
					int p1	= OF->G_R[ s ][ r ][ n1 ];

					if( p1 < p2 )
					{
						out << "g" << id_g + 1 << "( p1 = " << p1 + 1;
						out << ", p2 = " << p2 + 1 << " ) = ";
						out << g[ id_g++ ] << endl;
					}
				}
			}
		}
	}

	out << endl;
}

static	void	P3_out_h
(
	ostream &			out,
	const P3 *			OF,
	const	double *	h
)
{
	int	id_h	= 0;

	out << "Eq. (11)" << endl;
	for( int u = 0 ; u < OF->N_S ; u++ ) 
	{
		out << "h" << id_h + 1 << "( u = " << u + 1 << " ) = ";
		out << h[ id_h++ ] << endl;
	}

	out << "Eq. (12)" << endl;
	for( int s = 0 ; s < OF->N_S ; s++ ) 
	{
		out << "h" << id_h + 1 << "( s = " << s + 1 << " ) = ";
		out << h[ id_h++ ] << endl;
	}

	out << "Eq. (13)" << endl;
	for( int s = 0 ; s < OF->N_S ; s++ ) 
	{
		out << "s = " << s + 1 << endl;

		for( int v = 0 ; v < OF->N_R[s] ; v++ ) 
		{
			out << "h" << id_h + 1 << "( v = " << v + 1 << " ) = ";
			out << h[ id_h++ ] << endl;
		}
	}

	out << "Eq. (14)" << endl;
	for( int s = 0 ; s < OF->N_S ; s++ ) 
	{
		out << "s = " << s + 1 << endl;

		for( int r = 0 ; r < OF->N_R[s] ; r++ ) 
		{
			out << "h" << id_h + 1 << "( r = " << r + 1 << " ) = ";
			out << h[ id_h++ ] << endl;
		}
	}

	out << "Eq. (16)" << endl;
	for( int p = 0 ; p < OF->N_P ; p++ ) 
	{
		out << "h" << id_h + 1 << "( p = " << p + 1 << " ) = ";
		out << h[ id_h++ ] << endl;
	}

	out << "Eq. (17)" << endl;
	for( int p = 0 ; p < OF->N_P ; p++ ) 
	{
		out << "h" << id_h + 1 << "( p = " << p + 1 << " ) = ";
		out << h[ id_h++ ] << endl;
	}

	out << endl;
}


static	void	P3_out_y
(
	ostream &			out,
	const P3 *			OF,
	const	double *	y
)
{
	int			id_y	= 0;	
	
	out << "y_S[s][u] = " << endl;
	for( int s = 0 ; s < OF->N_S ; s++ ) 
	{
		for( int u = 0 ; u < OF->N_S ; u++ ) 
		{
			out << y[ id_y++ ] << ", ";
		}
		out << endl;
	}

	out << "y_R[s][r][v] = " << endl;
	for( int s = 0 ; s < OF->N_S ; s++ ) 
	{
		out << "y_R[" << s + 1 << "][r][v] = " << endl;
		for( int r = 0 ; r < OF->N_R[ s ] ; r++ ) 
		{
			for( int v = 0 ; v < OF->N_R[ s ] ; v++ ) 
			{
				out << y[ id_y++ ] << ", ";
			}
			out << endl;
		}
	}

	out << "y_K[l][k] = " << endl;
	for( int l = 0 ; l < OF->N_L ; l++ ) 
	{
		for( int k = 0 ; k < OF->N_K ; k++ ) 
		{
			out << y[ id_y++ ] << ", ";
		}
		out << endl;
	}

	out << "y_P[l][p] = " << endl;
	for( int l = 0 ; l < OF->N_L ; l++ ) 
	{
		out << "y_P[" << l + 1 << "][p] = " << endl;
		for( int p = 0 ; p < OF->N_P ; p++ ) 
		{
			out << y[ id_y++ ] << ", ";
		}
		out << endl;
	}

	out << "y_T[p] = " << endl;
	for( int p = 0 ; p < OF->N_P ; p++ ) 
	{
		out << y[ id_y++ ] << ", ";
	}
	out << endl;
}

static	void	P3_out_cp
(
	ostream &			out,
	const P3 *			OF,
	const	double *	y
)
{
	int	*		cp;
	int			cmax	= 0;
	char		buf[ 1024 ];

	for( int	p = 0 ; p < OF->N_P ; p++ )
	{
		int	c	= OF->C_P( p, &y[ OF->Y_P_BASE ], &y[ OF->Y_T_BASE ] );

		if( cmax < c )
		{
			cmax	= c;
		}
	}
	cmax++;

	cp	= new int [ cmax ]; //memory allocation for cp
	for( int c = 0 ; c < cmax ; c++ )
	{
		cp [ c ]	= 0;
	}

	for( int	p = 0 ; p < OF->N_P ; p++ )
	{
		int	c	= OF->C_P( p, &y[ OF->Y_P_BASE ], &y[ OF->Y_T_BASE ] );

		if(		 0 == cp[ c ] )		{	cp[ c ]	= p + 1;	}
		else if( 0 <  cp[ c ] )		{	cp[ c ]	= -2;		}
		else						{	cp[ c ]--;			}
	}

	out << "C_P[p] = " << endl;
	for( int c = 0 ; c < cmax ; c++ ) 
	{
		int	p = cp[ c ];
		if(		 0 == p )
		{
			sprintf( buf, "%05d,----,----,----,----,----", c + 1 );
		}
		else if( 0 >  p )
		{
			sprintf( buf, "%05d,  [overlap %04d]  ", c + 1, -p );
		}
		else
		{
			sprintf( buf, "%05d,%04d,%04d,%04d,%04d,%04d", c + 1, p, 
							OF->S_P[ p - 1 ] + 1, OF->R_P[ p - 1 ] + 1, 
							OF->K_P[ p - 1 ] + 1, (int)y[ OF->Y_T_BASE + p - 1 ] ); 
		}
		out << buf << endl;
	}
	out << endl;

	delete	[]	cp;
}