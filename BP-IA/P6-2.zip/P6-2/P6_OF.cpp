/*
 * P6 wrapper
 * Last update on 2013/02/21
 */

/* Objective Function Class */
#include "objectiveFunction.h"

/* P6 class */
P6 P6_I;

/* Constructor */
ObjectiveFunction::ObjectiveFunction()
{
	/* common part */
	N = P6_I.N_x;
	M = P6_I.M - 2 * P6_I.N - 2 * P6_I.K - 2 * P6_I.K;
	Q = P6_I.Q - 1;
	allocation();
	fill(p[0], 0.0);
	fill(q[0], 0.0);
	fill(p[1], -10.0);
	fill(q[1], 10.0);
	fill(p[2], -10.0);
	fill(q[2], 10.0);
	name = "P6";
	f_opt = -100000.0;
	r_rc = 10000.0 + 1.0E-06;
	gr_type = 1;

	/* private part */
	x_tmp = new double [P6_I.N_x];
	y_tmp = new double [P6_I.N_y];
	f_tmp = new double [P6_I.P];
	g_tmp = new double [P6_I.M];
	h_tmp = new double [P6_I.Q];
	fx = new double [P6_I.N_x];
	gx = new double *[P6_I.M];
	for (int m = 0; m < P6_I.M; m++) {
		gx[m] = new double [P6_I.N_x];
	}
	hx = new double *[P6_I.Q];
	for (int q = 0; q < P6_I.Q; q++) {
		hx[q] = new double [P6_I.N_x];
	}
}

/*
 * double ObjectiveFunction::eval(const ColumnVector &, const int)
 * Summary : evaluation objective function and constraint conditions
 * Argument
 *  1. const ColumnVector &x : decision variable vector
 *  2. const int tag : tag number
 */
double ObjectiveFunction::eval(const ColumnVector &x, const int tag)
{
	incrementFEs(tag);
	for (int n = 0; n < P6_I.N_x; n++) {
		x_tmp[n] = x(n);
	}
	P6_I.evaluation(x_tmp, y_tmp, f_tmp, g_tmp, h_tmp);
	if (tag == 0) {
		return -f_tmp[0];
	} else if (tag < M + 1) {
		return g_tmp[tag - 1 + 2 * P6_I.N + 2 * P6_I.K];
	} else {
		int idx = tag - 1 - M;
		if (idx < P6_I.N) {
			return h_tmp[idx];
		} else {
			return h_tmp[idx + 1];
		}
	}
}

/* Set all components of gradient vector */
void ObjectiveFunction::setGradient2(const ColumnVector &x, ColumnVector *grd)
{
	for (int n = 0; n < P6_I.N_x; n++) {
		x_tmp[n] = x(n);
	}
	P6_I.gradient(x_tmp, y_tmp, fx, gx, hx);
	int i = 0;
	for (int n = 0; n < N; n++) {
		grd[i](n) = -fx[n];
	}
	i++;
	for (int m = 0; m < M; m++) {
		for (int n = 0; n < N; n++) {
			grd[i](n) = gx[m + 2 * P6_I.N + 2 * P6_I.K][n];
		}
		i++;
	}
	for (int q = 0; q < Q; q++) {
		for (int n = 0; n < N; n++) {
			if (q < P6_I.N) {
				grd[i](n) = hx[q][n];
			} else {
				grd[i](n) = hx[q + 1][n];
			}
		}
		i++;
	}
}
