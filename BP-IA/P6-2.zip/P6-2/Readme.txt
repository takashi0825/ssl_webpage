## C++ source codes of the optimization benchmark problem for the series-parallel switching of photovoltaic modules programming ##
These codes are edited by the investigating R&D commitee on new development of computational intelligence techniques and their applications to industrial systems, the institute of electrical engineers of Japan.

These codes are based on the series-parallel switching of photovoltaic modules optimization problem in [1].
Specific formulation used in this implementation is given in "P6_formulation.pdf".
[1] T. Hayashi: "The serial-parallel switching of photovoltaic modules and mixed integer programming", Proc. of the 2014 Annual Meeting on the Institute of Electrical Engineers of Japan (Mar. 2014) [in Japanese]

-- Files --
# P6.cpp: P6 (the serial-parallel switching of photovoltaic modules programming problem) class main file.
# P6.h: P6 class header file.
# P6_evaluation.cpp: sample file to test P6 class.
# P6_solution_x.txt: the solution evaluated in P6_sample.cpp.
# P6_solution_y.txt: the solution evaluated in P6_sample.cpp.
# P6_tolerance.conf: tolerance for constraint violations.
# P6_zzz.conf: constants read in the private method "P6::initialization" of P6.cpp.

-- Implementing the sample code --
# Visual C++
	cl P6.cpp P6_evaluation.cpp /FeP6.exe /EHsc
	P6.exe
# gcc
	g++ P6.cpp P6_evaluation.cpp -o P6.out
	./P6.out

-- Public methods --
# void P6::evaluation(double *x, double *y, double *f, double *g, double *h)
  This function sets objective function values f(x, y) to f, inequality condition function values g(x, y) to g, and equality condition function values h(x, y) to h.
# void P6::checkFeasibility(double *x, double *y)
  This function returns feasibility of decision variables.

-- Public properties --
# int P6.N_x : number of continuous decision variables
# int P6.N_y : number of discrete decision variables
# int P6.P : number of objective funcitons
# int P6.M : number of inequality conditions
# int P6.Q : number of equality conditions
# double P6.eps : tolerance for constraint violations
